# AI Visual Merchandiser - HYBRID Edition

🎨 **Gemini API + Vertex AI Imagen Hybrid System**

This version uses:
- **Gemini API** (simple API key) for analytics, agents, and vision analysis
- **Vertex AI Imagen** (project-based auth) for actual image editing

---

## ✨ Features

### ✅ Working Features:
- **Analytics Dashboard** - Sales metrics, zone performance, slow movers
- **Daily Plans** - Multi-agent AI coordination for merchandising strategies
- **Display Creation** - AI-generated visual merchandising plans
- **Image Editor** - Hybrid Gemini vision + Imagen editing
  - Gemini analyzes images and understands context
  - Generates precise editing instructions
  - Imagen applies actual image edits

### 🔧 How Image Editing Works:
1. User uploads display fixture photo
2. User says: "Make the pillow red"
3. **Gemini Vision** analyzes and says: "I see a gray decorative pillow on the left side of the white couch. Change it to bright red while preserving texture."
4. **Imagen** applies the precise edit
5. Returns edited image

---

## 🚀 Quick Start

### Prerequisites:
- Python 3.9+
- Node.js 16+
- Gemini API key (free from https://aistudio.google.com/app/apikey)
- GCP account with Vertex AI enabled (for image editing)


## 🔑 Configuration: 
Configure `.env` file with your gemini keys (values are listed as '...'.   Do not change the hardcoded values for now)

### Step 1: Backend Setup

```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure .env (already includes your keys)
# Edit if needed: nano .env

# Authenticate with GCP (for Imagen)
gcloud auth application-default login

# Run backend
python3 app.py
```

**Expected output:**
```
Starting HYBRID system:
  Gemini API Key: ********************M4AM
  Gemini Model: gemini-2.0-flash-exp
  GCP Project (for Imagen): nvidia-476412
✓ Database initialized: json_mock
✓ Gemini agent system initialized
✓ Hybrid image editor initialized (Gemini + Imagen)
 * Running on http://0.0.0.0:5000
```

### Step 2: Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm start
```

Frontend will open at `http://localhost:3000`

---

### Enable Imagen (if not already done):

```bash
# Set project
gcloud config set project nvidia-476412

# Enable Vertex AI API
gcloud services enable aiplatform.googleapis.com

# Authenticate
gcloud auth application-default login
```
---

## 📊 API Endpoints

### Analytics:
- `GET /api/analytics/zones?days=30` - Zone performance
- `GET /api/analytics/top-performers?limit=10` - Top SKUs
- `GET /api/analytics/slow-movers` - Slow moving items

### Daily Plans:
- `POST /api/daily-plan` - Generate comprehensive plan
  ```json
  {"zone": "Front Window"}
  ```

### Display Creation:
- `POST /api/display/create` - Create display plan
  ```json
  {"prompt": "Summer beach theme", "zone": "Front Window"}
  ```

### Image Editing (Hybrid):
- `POST /api/display-editor/upload-base` - Upload base image
  ```json
  {"zone": "Front Window", "image": "data:image/png;base64,..."}
  ```
  
- `POST /api/display-editor/edit` - Apply edit
  ```json
  {"zone": "Front Window", "command": "Make the pillow red"}
  ```

- `POST /api/display-editor/reset` - Reset to original
  ```json
  {"zone": "Front Window"}
  ```

---

## 🔍 Troubleshooting

### Image editing returns "Analysis only - Imagen not available"
**Cause:** Imagen not initialized (GCP issue)

**Fix:**
```bash
# Check if API is enabled
gcloud services list --enabled | grep aiplatform

# If not enabled:
gcloud services enable aiplatform.googleapis.com

# Re-authenticate
gcloud auth application-default login

# Restart backend
```

### "404 Publisher Model not found"
**Cause:** Wrong region or model version

**Fix:** Try different region in `.env`:
```env
GCP_LOCATION=us-east4  # or us-west1, europe-west1
```

### Gemini API errors
**Cause:** API key issue or rate limits

**Fix:**
- Check API key is valid
- Gemini 2.0 Flash has 15 RPM free tier
- Upgrade or wait if rate limited

---

## 💰 Costs

### Free Tier:
- **Gemini API:** 15 requests/minute free (plenty for development)
- **Vertex AI Imagen:** Pay-per-use (~$0.02-0.05 per image)

### Estimated Monthly Cost (Light Usage):
- Analytics/Plans: **$0** (within Gemini free tier)
- Image Editing: **$5-20** (100-500 edits/month)

---

## 📁 Project Structure

```
ai-visual-merchandiser-hybrid/
├── backend/
│   ├── app.py                 # Flask server
│   ├── agent_system.py        # Hybrid AI system (Gemini + Imagen)
│   ├── database_manager.py    # Data access layer
│   ├── config.py              # Configuration
│   ├── requirements.txt       # Python dependencies
│   └── .env                   # Environment variables
├── frontend/
│   ├── src/
│   │   ├── components/        # React components
│   │   └── services/          # API client
│   ├── package.json
│   └── public/
└── database/
    └── mock_data.json         # Sample data
```

---

## 🚀 Next Steps

1. **Test with your images** - Upload real display fixtures
2. **Try iterative editing** - Make multiple changes
3. **Customize prompts** - Adjust agent instructions
4. **Add more zones** - Expand to all display areas
5. **Deploy** - Move to production when ready


