"""
Hybrid Agentic AI System: Gemini API + Vertex AI Imagen
- Uses Gemini API (simple API key) for text analysis and agents
- Uses Vertex AI Imagen for actual image editing
"""

import google.generativeai as genai
import vertexai
from vertexai.preview.vision_models import ImageGenerationModel, Image as VertexImage
from typing import Dict, List, Optional
import json
from datetime import datetime
import base64
import io

class GeminiAgentSystem:
    """Main agentic AI system coordinator - Uses Gemini API"""
    
    def __init__(self, gemini_api_key: str, model_name: str, db_manager):
        # Configure Gemini API
        genai.configure(api_key=gemini_api_key)
        
        self.model_name = model_name
        self.db_manager = db_manager
        
        # Initialize agents
        self.orchestrator = OrchestratorAgent(model_name, db_manager)
        self.product_intelligence = ProductIntelligenceAgent(model_name, db_manager)
        self.display_builder = DisplayStoryBuilderAgent(model_name, db_manager)
        
        # Conversation history
        self.conversation_history = []
    
    def process_request(self, user_message: str, context: Optional[Dict] = None) -> Dict:
        """Main entry point for processing user requests"""
        
        # Add to conversation history
        self.conversation_history.append({
            'role': 'user',
            'message': user_message,
            'timestamp': datetime.now().isoformat()
        })
        
        # Orchestrator decides which agent(s) to use
        routing_decision = self.orchestrator.route_request(user_message, context)
        
        response = None
        
        # Check for multi-agent routing
        if routing_decision['agent'] == 'multi_agent':
            response = self._process_multi_agent(user_message, routing_decision, context)
        
        elif routing_decision['agent'] == 'product_intelligence':
            response = self.product_intelligence.process(
                user_message, 
                routing_decision.get('parameters', {})
            )
        
        elif routing_decision['agent'] == 'display_builder':
            response = self.display_builder.process(
                user_message,
                routing_decision.get('parameters', {})
            )
        
        else:
            # General response
            response = {
                'type': 'general',
                'message': "I can help you with product analysis or display planning. What would you like to do?"
            }
        
        # Add to conversation history
        self.conversation_history.append({
            'role': 'assistant',
            'message': response,
            'timestamp': datetime.now().isoformat()
        })
        
        return response
    
    def _process_multi_agent(self, user_message: str, routing_decision: Dict, context: Optional[Dict] = None) -> Dict:
        """Process requests requiring multiple agents"""
        results = {}
        
        needs_product_data = routing_decision.get('needs_product_data', False)
        needs_display_plan = routing_decision.get('needs_display_plan', False)
        
        if context:
            needs_product_data = needs_product_data or context.get('needs_product_data', False)
            needs_display_plan = needs_display_plan or context.get('needs_display_plan', False)
        
        # Get product intelligence first
        if needs_product_data:
            results['product_intelligence'] = self.product_intelligence.process(
                user_message,
                routing_decision.get('parameters', {})
            )
        
        # Then use those insights for display building
        if needs_display_plan:
            display_params = routing_decision.get('parameters', {})
            if 'product_intelligence' in results:
                display_params['product_data'] = results['product_intelligence']
            
            results['display_plan'] = self.display_builder.process(
                user_message,
                display_params
            )
        
        return {
            'type': 'multi_agent_response',
            'results': results
        }


class OrchestratorAgent:
    """Routes requests to appropriate specialized agents"""
    
    def __init__(self, model_name: str, db_manager):
        self.model = genai.GenerativeModel(model_name)
        self.db_manager = db_manager
    
    def route_request(self, user_message: str, context: Optional[Dict] = None) -> Dict:
        """Determine which agent should handle the request"""
        
        if context and context.get('needs_product_data') and context.get('needs_display_plan'):
            return {
                'agent': 'multi_agent',
                'reasoning': 'Request requires both product analysis and display planning',
                'needs_product_data': True,
                'needs_display_plan': True,
                'parameters': context
            }
        
        prompt = f"""Analyze this request and route to the appropriate agent.

User Request: {user_message}
Context: {json.dumps(context) if context else 'None'}

Agents available:
- product_intelligence: SKU analysis, sales data, inventory
- display_builder: Visual displays, merchandising plans
- multi_agent: Needs both product analysis AND display creation

Respond with JSON:
{{"agent": "...", "reasoning": "...", "needs_product_data": true/false, "needs_display_plan": true/false}}"""
        
        try:
            response = self.model.generate_content(prompt)
            response_text = response.text.strip()
            
            if response_text.startswith('```'):
                response_text = response_text.split('```')[1]
                if response_text.startswith('json'):
                    response_text = response_text[4:]
                response_text = response_text.strip()
            
            routing = json.loads(response_text)
            routing.setdefault('needs_product_data', False)
            routing.setdefault('needs_display_plan', False)
            
            return routing
            
        except Exception as e:
            print(f"Orchestrator error: {e}")
            return {
                'agent': 'general',
                'reasoning': 'Error in routing',
                'needs_product_data': False,
                'needs_display_plan': False,
                'parameters': {}
            }


class ProductIntelligenceAgent:
    """Handles SKU analysis, sales data, and product insights"""
    
    def __init__(self, model_name: str, db_manager):
        self.model = genai.GenerativeModel(model_name)
        self.db_manager = db_manager
    
    def process(self, user_message: str, parameters: Dict) -> Dict:
        """Process product intelligence requests"""
        
        context_data = self._gather_context(user_message, parameters)
        
        prompt = f"""You are a Product Intelligence Agent for visual merchandising.

User Request: {user_message}

Data Available:
{json.dumps(context_data, indent=2)}

Provide detailed analysis with actionable insights."""
        
        try:
            response = self.model.generate_content(prompt)
            
            return {
                'type': 'product_intelligence',
                'message': response.text,
                'data': context_data,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                'type': 'error',
                'message': f'Error processing product intelligence: {str(e)}'
            }
    
    def _gather_context(self, user_message: str, parameters: Dict) -> Dict:
        """Gather relevant product and sales data"""
        context = {}
        
        context['top_performers'] = self.db_manager.get_top_performers(limit=10, days=30)
        context['slow_movers'] = self.db_manager.get_slow_movers()
        context['new_arrivals'] = self.db_manager.get_new_arrivals(days=14)
        
        if 'zone' in parameters:
            zone = parameters['zone']
            context['zone_performance'] = self.db_manager.get_sales_by_zone(zone, days=30)
        
        return context


class DisplayStoryBuilderAgent:
    """Creates display concepts and execution plans"""
    
    def __init__(self, model_name: str, db_manager):
        self.model = genai.GenerativeModel(model_name)
        self.db_manager = db_manager
    
    def process(self, user_message: str, parameters: Dict) -> Dict:
        """Process display building requests"""
        
        context_data = self._gather_context(user_message, parameters)
        
        product_context = ""
        if 'product_data' in parameters:
            product_context = f"\n\nProduct Intelligence Insights:\n{json.dumps(parameters['product_data'], indent=2)}"
        
        prompt = f"""You are a Display Story Builder for visual merchandising.

User Request: {user_message}

Context:
{json.dumps(context_data, indent=2)}
{product_context}

Create a comprehensive display plan with:
1. Display Concept & Theme
2. Featured Products & Placement
3. Visual Elements
4. Execution Instructions
5. Staff Talking Points"""
        
        try:
            response = self.model.generate_content(prompt)
            
            return {
                'type': 'display_plan',
                'message': response.text,
                'context': context_data,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                'type': 'error',
                'message': f'Error creating display plan: {str(e)}'
            }
    
    def _gather_context(self, user_message: str, parameters: Dict) -> Dict:
        """Gather relevant context for display creation"""
        context = {}
        
        all_skus = self.db_manager.get_all_skus()
        context['available_products'] = all_skus[:20] if len(all_skus) > 20 else all_skus
        context['slow_movers_summary'] = len(self.db_manager.get_slow_movers())
        context['recent_displays'] = self.db_manager.get_display_history()
        context['zone_performance'] = self.db_manager.get_zone_performance(days=30)
        
        return context


class HybridImageEditor:
    """
    HYBRID Image Editor:
    - Uses Gemini API for vision analysis and instruction generation
    - Uses Vertex AI Imagen for actual image editing
    """
    
    def __init__(self, gemini_api_key: str, gemini_model: str, gcp_project_id: str, gcp_location: str, db_manager):
        # Gemini API for analysis (NOT through Vertex AI)
        genai.configure(api_key=gemini_api_key)
        self.gemini = genai.GenerativeModel(gemini_model)
        
        # Vertex AI for Imagen ONLY (image generation/editing)
        try:
            vertexai.init(project=gcp_project_id, location=gcp_location)
            # Use correct Imagen model - NOT gemini
            self.imagen = ImageGenerationModel.from_pretrained("imagegeneration@006")
            print("✓ Hybrid Image Editor initialized (Gemini API + Vertex Imagen)")
        except Exception as e:
            print(f"⚠ Imagen initialization failed: {e}")
            print(f"  Error details: {str(e)}")
            print("  Trying alternative Imagen version...")
            try:
                self.imagen = ImageGenerationModel.from_pretrained("imagegeneration@005")
                print("✓ Imagen initialized with version 005")
            except Exception as e2:
                print(f"  Alternative also failed: {e2}")
                print("  Image editor will work in analysis-only mode")
                self.imagen = None
        
        self.db_manager = db_manager
        self.sessions = {}
    
    def create_session(self, user_id: str, zone: str, base_image_b64: str) -> Dict:
        """Create a new editing session"""
        session_key = f"{user_id}_{zone}"
        
        self.sessions[session_key] = {
            'base_image': base_image_b64,
            'current_image': base_image_b64,
            'edit_history': [],
            'full_context': 'Store display fixture with neutral background',
            'zone': zone,
            'created_at': datetime.now().isoformat()
        }
        
        return self.sessions[session_key]
    
    def get_session(self, user_id: str, zone: str) -> Optional[Dict]:
        """Get existing session"""
        session_key = f"{user_id}_{zone}"
        return self.sessions.get(session_key)
    
    def apply_edit(self, user_id: str, zone: str, command: str) -> Dict:
        """
        Apply edit using hybrid approach:
        1. Gemini analyzes image + command
        2. Generates precise editing instruction
        3. Imagen applies the edit
        """
        session_key = f"{user_id}_{zone}"
        
        if session_key not in self.sessions:
            return {
                'error': 'No session found. Please upload a base image first.',
                'success': False
            }
        
        session = self.sessions[session_key]
        
        # STEP 1: Gemini Vision Analysis
        try:
            # Decode current image
            image_data = base64.b64decode(session['current_image'].split(',')[1] if ',' in session['current_image'] else session['current_image'])
            
            # Prepare for Gemini
            image_part = {
                "mime_type": "image/png",
                "data": image_data
            }
            
            # Analysis prompt
            analysis_prompt = f"""Analyze this retail display image and the user's edit request.

Current context: {session['full_context']}

Previous edits: {self._format_history(session['edit_history'])}

User wants: "{command}"

Provide JSON:
{{
  "scene_description": "what you see",
  "target_found": true/false,
  "target_details": "what needs to change",
  "editing_instruction": "precise instruction for image AI",
  "updated_context": "how display will look after edit",
  "edit_summary": "brief summary"
}}"""

            print(f"  Analyzing with Gemini...")
            gemini_response = self.gemini.generate_content([analysis_prompt, image_part])
            
            # Parse response
            response_text = gemini_response.text.strip()
            if response_text.startswith('```'):
                response_text = response_text.split('```')[1]
                if response_text.startswith('json'):
                    response_text = response_text[4:]
                response_text = response_text.strip()
            
            analysis = json.loads(response_text)
            print(f"  ✓ Gemini analysis complete")
            
            if not analysis.get('target_found', False):
                return {
                    'success': False,
                    'error': f"Could not identify target: {analysis.get('target_details', 'Not found')}",
                    'analysis': analysis
                }
            
        except Exception as e:
            print(f"  Gemini analysis error: {e}")
            return {
                'success': False,
                'error': f'Vision analysis failed: {str(e)}'
            }
        
        # STEP 2: Imagen Editing (if available)
        if self.imagen is None:
            # Analysis-only mode
            session['edit_history'].append({
                'command': command,
                'summary': analysis['edit_summary'],
                'timestamp': datetime.now().isoformat()
            })
            session['full_context'] = analysis['updated_context']
            
            return {
                'success': True,
                'image': session['current_image'],
                'summary': analysis['edit_summary'],
                'full_context': session['full_context'],
                'history': session['edit_history'],
                'note': 'Analysis only - Imagen not available. Instructions generated.',
                'analysis': analysis
            }
        
        # Apply actual image edit with Imagen
        try:
            print(f"  Editing with Imagen...")
            
            # Convert base64 to Imagen format
            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                tmp.write(image_data)
                tmp_path = tmp.name
            
            base_image = VertexImage.load_from_file(tmp_path)
            
            # Edit with Gemini's precise instruction
            # Try edit_image without edit_mode (API may have changed)
            try:
                edited_response = self.imagen.edit_image(
                    prompt=analysis['editing_instruction'],
                    base_image=base_image,
                    number_of_images=1
                )
            except TypeError as e:
                # Fallback: Try with mask parameter instead
                print(f"    Trying alternative edit method...")
                edited_response = self.imagen.edit_image(
                    prompt=analysis['editing_instruction'],
                    base_image=base_image
                )
            
            # Get edited image
            edited_images = edited_response.images if hasattr(edited_response, 'images') else [edited_response]
            edited_image = edited_images[0]
            
            # Convert back to base64
            edited_bytes = edited_image._image_bytes
            edited_b64 = f"data:image/png;base64,{base64.b64encode(edited_bytes).decode()}"
            
            # Update session
            session['current_image'] = edited_b64
            session['edit_history'].append({
                'command': command,
                'summary': analysis['edit_summary'],
                'timestamp': datetime.now().isoformat()
            })
            session['full_context'] = analysis['updated_context']
            
            print(f"  ✓ Image edited successfully")
            
            # Cleanup
            import os
            os.unlink(tmp_path)
            
            return {
                'success': True,
                'image': edited_b64,
                'summary': analysis['edit_summary'],
                'full_context': session['full_context'],
                'history': session['edit_history'],
                'analysis': analysis
            }
            
        except Exception as e:
            print(f"  Imagen editing error: {e}")
            return {
                'success': False,
                'error': f'Image editing failed: {str(e)}',
                'analysis': analysis
            }
    
    def reset_session(self, user_id: str, zone: str) -> Dict:
        """Reset display to base image"""
        session_key = f"{user_id}_{zone}"
        
        if session_key not in self.sessions:
            return {
                'error': 'No session found',
                'success': False
            }
        
        session = self.sessions[session_key]
        base_image = session['base_image']
        
        session['current_image'] = base_image
        session['edit_history'] = []
        session['full_context'] = 'Store display fixture with neutral background'
        
        return {
            'success': True,
            'image': base_image,
            'message': 'Display reset to original',
            'full_context': session['full_context']
        }
    
    def _format_history(self, history: List[Dict]) -> str:
        """Format edit history for context"""
        if not history:
            return "No previous edits"
        
        formatted = []
        for idx, edit in enumerate(history, 1):
            formatted.append(f"{idx}. {edit['command']} → {edit['summary']}")
        
        return "\n".join(formatted)
