"""
Configuration for AI Visual Merchandiser
HYBRID: Gemini API + Vertex AI Imagen
"""
import os
from dotenv import load_dotenv

class Config:
    # Flask
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Gemini API Configuration (for text/agents)
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'your-api-key-here')
    GEMINI_MODEL = os.getenv('GEMINI_MODEL', 'gemini-2.0-flash-exp')
    
    # GCP/Vertex AI Configuration (for Imagen only)
    GCP_PROJECT_ID = os.getenv('GCP_PROJECT_ID', 'your-gcp-project-id')
    GCP_LOCATION = os.getenv('GCP_LOCATION', 'us-central1')
    
    # Database Configuration
    USE_CLOUD_SQL = os.getenv('USE_CLOUD_SQL', 'false').lower() == 'true'
    
    # Cloud SQL settings (when enabled)
    DB_USER = os.getenv('DB_USER', 'postgres')
    DB_PASSWORD = os.getenv('DB_PASSWORD', '')
    DB_NAME = os.getenv('DB_NAME', 'visual_merchandiser')
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_PORT = os.getenv('DB_PORT', '5432')
    
    # Mock data path (for development)
    MOCK_DATA_PATH = os.getenv('MOCK_DATA_PATH', '../database/mock_data.json')
    
    # Application Settings
    MAX_CONTEXT_LENGTH = 128000
    TEMPERATURE = 0.7
    TOP_P = 0.95
    TOP_K = 40
    
    @classmethod
    def load_from_env(cls):
        """Load/reload configuration from environment variables"""
        load_dotenv()
        
        cls.SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
        cls.GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'your-api-key-here')
        cls.GEMINI_MODEL = os.getenv('GEMINI_MODEL', 'gemini-2.0-flash-exp')
        cls.GCP_PROJECT_ID = os.getenv('GCP_PROJECT_ID', 'your-gcp-project-id')
        cls.GCP_LOCATION = os.getenv('GCP_LOCATION', 'us-central1')
        cls.USE_CLOUD_SQL = os.getenv('USE_CLOUD_SQL', 'false').lower() == 'true'
        cls.DB_USER = os.getenv('DB_USER', 'postgres')
        cls.DB_PASSWORD = os.getenv('DB_PASSWORD', '')
        cls.DB_NAME = os.getenv('DB_NAME', 'visual_merchandiser')
        cls.DB_HOST = os.getenv('DB_HOST', 'localhost')
        cls.DB_PORT = os.getenv('DB_PORT', '5432')
        cls.MOCK_DATA_PATH = os.getenv('MOCK_DATA_PATH', '../database/mock_data.json')
