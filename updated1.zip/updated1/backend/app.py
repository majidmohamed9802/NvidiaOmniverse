from flask import Flask, request, jsonify
from flask_cors import CORS
from config import Config
from database_manager import DatabaseManager
from agent_system import GeminiAgentSystem, HybridImageEditor
import os

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Load configuration
Config.load_from_env()

print(f"Starting HYBRID system:")
print(f"  Gemini API Key: {'*' * 20 + Config.GEMINI_API_KEY[-8:] if len(Config.GEMINI_API_KEY) > 10 else 'NOT SET'}")
print(f"  Gemini Model: {Config.GEMINI_MODEL}")
print(f"  GCP Project (for Imagen): {Config.GCP_PROJECT_ID}")
print(f"  GCP Location: {Config.GCP_LOCATION}")
print(f"  Use Cloud SQL: {Config.USE_CLOUD_SQL}")
print(f"  Mock Data Path: {Config.MOCK_DATA_PATH}")

# Initialize database manager
try:
    db_manager = DatabaseManager(
        use_cloud_sql=Config.USE_CLOUD_SQL,
        mock_data_path=Config.MOCK_DATA_PATH
    )
    print(f"✓ Database initialized: {'cloud_sql' if Config.USE_CLOUD_SQL else 'json_mock'}")
except Exception as e:
    print(f"✗ Database initialization failed: {e}")
    db_manager = None

# Initialize AI agent system
agent_system = None
image_editor = None

def init_agent_system():
    """Initialize hybrid agent system"""
    global agent_system, image_editor
    try:
        # Initialize Gemini agents
        agent_system = GeminiAgentSystem(
            gemini_api_key=Config.GEMINI_API_KEY,
            model_name=Config.GEMINI_MODEL,
            db_manager=db_manager
        )
        print("✓ Gemini agent system initialized")
        
        # Initialize hybrid image editor (Gemini + Imagen)
        image_editor = HybridImageEditor(
            gemini_api_key=Config.GEMINI_API_KEY,
            gemini_model=Config.GEMINI_MODEL,
            gcp_project_id=Config.GCP_PROJECT_ID,
            gcp_location=Config.GCP_LOCATION,
            db_manager=db_manager
        )
        print("✓ Hybrid image editor initialized")
        
    except Exception as e:
        print(f"⚠ Agent system initialization failed: {e}")
        print("  Set GEMINI_API_KEY and configure GCP for full features")

# Try to initialize agent system
if Config.GEMINI_API_KEY and Config.GEMINI_API_KEY != 'your-api-key-here':
    init_agent_system()
else:
    print("⚠ Gemini API key not configured. Running in data-only mode.")

# ============================================================================
# Health Check
# ============================================================================

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'ai_enabled': agent_system is not None,
        'image_editing_enabled': image_editor is not None and image_editor.imagen is not None,
        'database': 'cloud_sql' if Config.USE_CLOUD_SQL else 'json_mock'
    })

# ============================================================================
# Analytics Endpoints
# ============================================================================

@app.route('/api/analytics/zones', methods=['GET'])
def get_zone_analytics():
    """Get zone performance analytics"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    days = int(request.args.get('days', 30))
    
    try:
        zones = db_manager.get_zone_performance(days=days)
        return jsonify(zones)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analytics/top-performers', methods=['GET'])
def get_top_performers():
    """Get top performing SKUs"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    days = int(request.args.get('days', 30))
    limit = int(request.args.get('limit', 10))
    
    try:
        performers = db_manager.get_top_performers(limit=limit, days=days)
        return jsonify(performers)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analytics/slow-movers', methods=['GET'])
def get_slow_movers():
    """Get slow moving SKUs"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    try:
        slow_movers = db_manager.get_slow_movers()
        return jsonify(slow_movers)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analytics/enhanced-insights', methods=['POST'])
def get_enhanced_insights():
    """Get enhanced AI insights with actionable recommendations"""
    if agent_system is None:
        return jsonify({'error': 'AI system not initialized'}), 503
    
    try:
        data = request.get_json()
        prompt = data.get('prompt', '')
        comparison_data = data.get('comparison_data', {})
        skus = data.get('skus', [])
        
        # Generate insights using AI
        response = agent_system.generate_insights(prompt)
        
        # Try to parse as JSON for structured response
        try:
            import json
            # Extract JSON from response if it's embedded in text
            message = response.get('message', '')
            if '{' in message and '}' in message:
                start = message.find('{')
                end = message.rfind('}') + 1
                json_str = message[start:end]
                parsed = json.loads(json_str)
                return jsonify(parsed)
        except:
            pass
        
        # Fallback to simple format if JSON parsing fails
        # Generate some default actions based on the data
        actions = []
        
        # Analyze SKU trends to generate recommendations
        if skus and comparison_data:
            # Simple heuristic: recommend actions for best and worst performers
            actions.append({
                'title': 'Move slow-moving items to prominent locations',
                'description': 'Items with declining sales should be relocated to high-traffic areas to increase visibility.',
                'action': 'move_item_to_front'
            })
            actions.append({
                'title': 'Restock bestsellers',
                'description': 'Popular items may be running low. Ensure adequate stock levels to meet demand.',
                'action': 'restock_item'
            })
            actions.append({
                'title': 'Create promotional display',
                'description': 'Highlight seasonal or trending items with special displays to drive sales.',
                'action': 'highlight_item'
            })
        
        return jsonify({
            'message': response.get('message', 'Analysis complete'),
            'actions': actions
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Week Management Endpoints
# ============================================================================

@app.route('/api/weeks/current', methods=['GET'])
def get_current_week():
    """Get current week number"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    try:
        current_week = db_manager.get_current_week()
        return jsonify({'current_week': current_week})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/weeks/advance', methods=['POST'])
def advance_week():
    """Advance to next week"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    try:
        result = db_manager.advance_week()
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/weeks/compare', methods=['GET'])
def compare_weeks():
    """Compare two weeks"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    week1 = int(request.args.get('week1', 1))
    week2 = int(request.args.get('week2', 2))
    
    try:
        comparison = db_manager.compare_weeks(week1, week2)
        return jsonify(comparison)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/weeks/sales', methods=['GET'])
def get_weekly_sales():
    """Get sales by week"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    week = request.args.get('week')
    week = int(week) if week else None
    
    try:
        sales = db_manager.get_sales_by_week(week)
        return jsonify(sales)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/skus/<sku_id>/trend', methods=['GET'])
def get_sku_trend(sku_id):
    """Get weekly trend for a SKU"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    weeks = int(request.args.get('weeks', 5))
    
    try:
        trend = db_manager.get_sku_weekly_trend(sku_id, weeks)
        return jsonify(trend)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# SKU Management Endpoints
# ============================================================================

@app.route('/api/skus', methods=['GET', 'POST'])
def manage_skus():
    """Get all SKUs or add a new one"""
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    if request.method == 'GET':
        try:
            skus = db_manager.get_all_skus()
            return jsonify(skus)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    elif request.method == 'POST':
        data = request.json
        
        if not data:
            return jsonify({'error': 'No SKU data provided'}), 400
        
        # Validate required fields
        required_fields = ['product_name', 'category', 'cost_price', 'selling_price']
        missing_fields = [f for f in required_fields if f not in data]
        
        if missing_fields:
            return jsonify({'error': f'Missing required fields: {", ".join(missing_fields)}'}), 400
        
        try:
            result = db_manager.add_sku(data)
            return jsonify(result), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500

# ============================================================================
# Daily Plan Endpoint
# ============================================================================

@app.route('/api/daily-plan', methods=['POST'])
def generate_daily_plan():
    """Generate daily display operations plan"""
    if agent_system is None:
        return jsonify({'error': 'AI system not initialized'}), 503
    
    data = request.json
    zone = data.get('zone', 'Central Mannequin')
    
    message = f"I need a complete daily display plan for {zone}. First, analyze our product performance to identify what should be featured. Then, create a detailed display plan with execution instructions."
    
    try:
        response = agent_system.process_request(
            message, 
            {
                'zone': zone,
                'needs_product_data': True,
                'needs_display_plan': True
            }
        )
        return jsonify(response)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/daily-plan/structured', methods=['POST'])
def generate_structured_plan():
    """Generate structured daily plan in professional format"""
    if agent_system is None:
        return jsonify({'error': 'AI system not initialized'}), 503
    
    if db_manager is None:
        return jsonify({'error': 'Database not initialized'}), 503
    
    data = request.json
    zone = data.get('zone', 'Central Mannequin')
    display_image = data.get('display_image')
    
    try:
        # Get product context
        top_performers = db_manager.get_top_performers(limit=10, days=7)
        slow_movers = db_manager.get_slow_movers()[:5]
        new_arrivals = db_manager.get_new_arrivals(days=14)
        
        # Build comprehensive prompt
        prompt = f"""Create a professional structured visual merchandising plan for {zone}.

Available Products Context:
- Top Performers (last 7 days): {[p['product_name'] + ' (' + p['sku_id'] + ')' for p in top_performers[:5]]}
- New Arrivals: {[p['product_name'] + ' (' + p['sku_id'] + ')' for p in new_arrivals[:3]]}
- Slow Movers needing promotion: {[p['product_name'] + ' (' + p['sku_id'] + ')' for p in slow_movers[:3]]}

Create a structured plan with these EXACT sections:

RESPOND IN VALID JSON FORMAT:
{{
  "products": [
    {{"name": "Product Name", "sku_id": "SKU00001"}},
    # Include 5-6 products: mix of top performers, new arrivals, and 1-2 slow movers
  ],
  "visual_prompt": "One paragraph describing the overall aesthetic, color story, textures, and mood",
  "execution_steps": [
    "Dress the main mannequin with [specific product] pairing it with [another product]",
    "Fold and display [product] neatly on mid-level shelf",
    "Position [product] prominently on display stand",
    "Ensure [product] is placed nearby to complement",
    "Remove [old product] as it is out of season",
    "Update signage to highlight [feature]"
  ],
  "talking_points": {{
    "whats_new": "Discover the fresh appeal of [new products]. Perfect for [season/occasion].",
    "coordinate_choice": "This display pairs [product A] with [product B], showing how to [style tip].",
    "slow_movers": "This display focuses on [slow mover products] and their [key selling points]."
  }}
}}

Make it specific with actual product names and SKU IDs from the available products list."""

        # Get AI response
        import google.generativeai as genai
        model = genai.GenerativeModel(Config.GEMINI_MODEL)
        response = model.generate_content(prompt)
        
        # Parse JSON response
        import json
        import re
        
        response_text = response.text.strip()
        
        # Remove markdown code blocks if present
        if response_text.startswith('```'):
            response_text = response_text.split('```')[1]
            if response_text.startswith('json'):
                response_text = response_text[4:]
            response_text = response_text.strip()
        
        # Extract JSON
        json_match = re.search(r'\{[\s\S]*\}', response_text)
        if json_match:
            structured_plan = json.loads(json_match.group())
        else:
            raise ValueError("Could not parse JSON from response")
        
        # Add zone and image
        structured_plan['zone'] = zone
        if display_image:
            structured_plan['visual_image'] = display_image
        
        return jsonify(structured_plan)
        
    except Exception as e:
        print(f"Error generating structured plan: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Display Creation Endpoint
# ============================================================================

@app.route('/api/display/create', methods=['POST'])
def create_display():
    """Create a new display plan"""
    if agent_system is None:
        return jsonify({'error': 'AI system not initialized'}), 503
    
    data = request.json
    prompt = data.get('prompt', '')
    zone = data.get('zone', 'Front Window')
    
    if not prompt:
        return jsonify({'error': 'Prompt is required'}), 400
    
    message = f"Create a visual merchandising display for {zone}. Requirements: {prompt}"
    
    try:
        response = agent_system.process_request(message, {'zone': zone})
        return jsonify(response)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Hybrid Image Editing Endpoints (Gemini Vision + Imagen)
# ============================================================================

@app.route('/api/display-editor/upload-base', methods=['POST'])
def upload_base_image():
    """Upload base stock image for a display area"""
    if image_editor is None:
        return jsonify({'error': 'Image editor not initialized'}), 503
    
    data = request.json
    zone = data.get('zone')
    image_base64 = data.get('image')
    user_id = data.get('user_id', 'default')
    
    if not zone or not image_base64:
        return jsonify({'error': 'zone and image are required'}), 400
    
    try:
        session = image_editor.create_session(user_id, zone, image_base64)
        return jsonify({
            'success': True,
            'message': f'Base image uploaded for {zone}',
            'zone': zone,
            'context': session['full_context']
        })
    except Exception as e:
        print(f"Error in upload_base_image: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/display-editor/edit', methods=['POST'])
def edit_display_image():
    """
    Apply edit command using hybrid approach:
    1. Gemini analyzes image + understands command
    2. Generates precise editing instruction
    3. Imagen applies the actual edit
    """
    if image_editor is None:
        return jsonify({'error': 'Image editor not initialized'}), 503
    
    data = request.json
    zone = data.get('zone')
    command = data.get('command')
    user_id = data.get('user_id', 'default')
    
    if not zone or not command:
        return jsonify({'error': 'zone and command are required'}), 400
    
    try:
        result = image_editor.apply_edit(user_id, zone, command)
        return jsonify(result)
    except Exception as e:
        print(f"Error in edit_display_image: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/display-editor/reset', methods=['POST'])
def reset_display_image():
    """Reset display to base image"""
    if image_editor is None:
        return jsonify({'error': 'Image editor not initialized'}), 503
    
    data = request.json
    zone = data.get('zone')
    user_id = data.get('user_id', 'default')
    
    if not zone:
        return jsonify({'error': 'zone is required'}), 400
    
    try:
        result = image_editor.reset_session(user_id, zone)
        return jsonify(result)
    except Exception as e:
        print(f"Error in reset_display_image: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/display-editor/session', methods=['GET'])
def get_display_session():
    """Get current session state"""
    if image_editor is None:
        return jsonify({'error': 'Image editor not initialized'}), 503
    
    zone = request.args.get('zone')
    user_id = request.args.get('user_id', 'default')
    
    if not zone:
        return jsonify({'error': 'zone is required'}), 400
    
    try:
        session = image_editor.get_session(user_id, zone)
        if session:
            return jsonify({
                'success': True,
                'zone': session['zone'],
                'current_image': session['current_image'],
                'full_context': session['full_context'],
                'history': session['edit_history']
            })
        else:
            return jsonify({
                'success': False,
                'message': 'No session found for this zone'
            })
    except Exception as e:
        print(f"Error in get_display_session: {e}")
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Run Server
# ============================================================================

if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=int(os.getenv('PORT', 5000)),
        debug=True
    )
