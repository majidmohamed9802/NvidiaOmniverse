"""
Database Manager - Handles both JSON (development) and Cloud SQL (production)
"""
import json
import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional

class DatabaseManager:
    def __init__(self, use_cloud_sql=False, mock_data_path=None):
        self.use_cloud_sql = use_cloud_sql
        self.mock_data_path = mock_data_path or '../database/mock_data.json'
        
        if not use_cloud_sql:
            self._load_mock_data()
        else:
            # TODO: Initialize Cloud SQL connection
            pass
    
    def _load_mock_data(self):
        """Load data from JSON file"""
        data_path = os.path.join(os.path.dirname(__file__), self.mock_data_path)
        with open(data_path, 'r') as f:
            self.data = json.load(f)
        
        # Initialize week tracking if not present
        if 'current_week' not in self.data:
            self.data['current_week'] = 5
        if 'week_history' not in self.data:
            self.data['week_history'] = []
    
    def _save_mock_data(self):
        """Save data back to JSON file"""
        data_path = os.path.join(os.path.dirname(__file__), self.mock_data_path)
        with open(data_path, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    # SKU Operations
    def get_all_skus(self) -> List[Dict]:
        """Get all SKUs"""
        if not self.use_cloud_sql:
            return self.data.get('skus', [])
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def get_skus(self) -> List[Dict]:
        """Alias for get_all_skus() - for compatibility"""
        return self.get_all_skus()
    
    def get_sku_by_id(self, sku_id: str) -> Optional[Dict]:
        """Get specific SKU by ID"""
        if not self.use_cloud_sql:
            for sku in self.data.get('skus', []):
                if sku['sku_id'] == sku_id:
                    return sku
            return None
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def get_skus_by_category(self, category: str) -> List[Dict]:
        """Get SKUs by category"""
        if not self.use_cloud_sql:
            return [sku for sku in self.data.get('skus', []) if sku['category'] == category]
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def get_new_arrivals(self, days: int = 30) -> List[Dict]:
        """Get new arrival SKUs"""
        if not self.use_cloud_sql:
            cutoff_date = datetime.now() - timedelta(days=days)
            return [
                sku for sku in self.data.get('skus', [])
                if datetime.strptime(sku['arrival_date'], '%Y-%m-%d') >= cutoff_date
            ]
        else:
            # TODO: Query from Cloud SQL
            pass
    
    # Sales Operations
    def get_sales_data(self, sku_id: Optional[str] = None, days: int = 90) -> List[Dict]:
        """Get sales data, optionally filtered by SKU"""
        if not self.use_cloud_sql:
            sales = self.data.get('sales_data', [])
            
            if sku_id:
                sales = [s for s in sales if s['sku_id'] == sku_id]
            
            cutoff_date = datetime.now() - timedelta(days=days)
            sales = [
                s for s in sales
                if datetime.strptime(s['sale_date'], '%Y-%m-%d') >= cutoff_date
            ]
            
            return sales
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def get_sales_by_zone(self, zone: str, days: int = 90) -> List[Dict]:
        """Get sales data by store zone"""
        if not self.use_cloud_sql:
            sales = self.get_sales_data(days=days)
            return [s for s in sales if s['store_zone'] == zone]
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def calculate_sku_velocity(self, sku_id: str, days: int = 30) -> Dict:
        """Calculate sales velocity for a SKU"""
        sales = self.get_sales_data(sku_id=sku_id, days=days)
        
        total_units = sum(s['quantity_sold'] for s in sales)
        total_revenue = sum(s['sale_amount'] for s in sales)
        
        return {
            'sku_id': sku_id,
            'days': days,
            'total_units_sold': total_units,
            'total_revenue': total_revenue,
            'avg_units_per_day': round(total_units / days, 2),
            'velocity_category': self._classify_velocity(total_units, days)
        }
    
    def _classify_velocity(self, units_sold: int, days: int) -> str:
        """Classify velocity as fast/medium/slow"""
        avg_per_day = units_sold / days
        
        if avg_per_day > 2:
            return 'fast'
        elif avg_per_day > 0.5:
            return 'medium'
        elif avg_per_day > 0:
            return 'slow'
        else:
            return 'no_movement'
    
    # Slow Movers Operations
    def get_slow_movers(self) -> List[Dict]:
        """Get all slow-moving SKUs"""
        if not self.use_cloud_sql:
            return self.data.get('slow_movers', [])
        else:
            # TODO: Query from Cloud SQL
            pass
    
    # Display Operations
    def get_display_history(self) -> List[Dict]:
        """Get all display history"""
        if not self.use_cloud_sql:
            return self.data.get('display_history', [])
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def create_display(self, display_data: Dict) -> Dict:
        """Create a new display plan"""
        if not self.use_cloud_sql:
            displays = self.data.get('display_history', [])
            new_id = max([d.get('display_id', 0) for d in displays], default=0) + 1
            
            display_data['display_id'] = new_id
            display_data['created_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            displays.append(display_data)
            self.data['display_history'] = displays
            self._save_mock_data()
            
            return display_data
        else:
            # TODO: Insert into Cloud SQL
            pass
    
    # Analytics Operations
    def get_zone_performance(self, days: int = 30) -> List[Dict]:
        """Get performance metrics by zone"""
        sales = self.get_sales_data(days=days)
        
        zone_metrics = {}
        for sale in sales:
            zone = sale['store_zone']
            if zone not in zone_metrics:
                zone_metrics[zone] = {
                    'zone': zone,
                    'units_sold': 0,
                    'revenue': 0
                }
            
            zone_metrics[zone]['units_sold'] += sale['quantity_sold']
            zone_metrics[zone]['revenue'] += sale['sale_amount']
        
        return list(zone_metrics.values())
    
    def get_top_performers(self, limit: int = 10, days: int = 30) -> List[Dict]:
        """Get top performing SKUs"""
        sales = self.get_sales_data(days=days)
        
        sku_performance = {}
        for sale in sales:
            sku_id = sale['sku_id']
            if sku_id not in sku_performance:
                sku_performance[sku_id] = {
                    'sku_id': sku_id,
                    'units_sold': 0,
                    'revenue': 0
                }
            
            sku_performance[sku_id]['units_sold'] += sale['quantity_sold']
            sku_performance[sku_id]['revenue'] += sale['sale_amount']
        
        # Add SKU details
        skus = {sku['sku_id']: sku for sku in self.get_all_skus()}
        for perf in sku_performance.values():
            sku = skus.get(perf['sku_id'], {})
            perf['product_name'] = sku.get('product_name', 'Unknown')
            perf['category'] = sku.get('category', 'Unknown')
        
        # Sort by revenue and return top performers
        sorted_perf = sorted(
            sku_performance.values(),
            key=lambda x: x['revenue'],
            reverse=True
        )
        
        return sorted_perf[:limit]
    
    # ============================================================================
    # Week Management
    # ============================================================================
    
    def get_current_week(self) -> int:
        """Get current week number"""
        if not self.use_cloud_sql:
            return self.data.get('current_week', 5)
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def advance_week(self) -> Dict:
        """Advance to next week"""
        if not self.use_cloud_sql:
            current = self.data.get('current_week', 5)
            new_week = current + 1
            self.data['current_week'] = new_week
            
            # Archive current week stats
            self.data['week_history'].append({
                'week': current,
                'archived_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            
            self._save_mock_data()
            
            return {
                'previous_week': current,
                'current_week': new_week,
                'message': f'Advanced from Week {current} to Week {new_week}'
            }
        else:
            # TODO: Update in Cloud SQL
            pass
    
    def get_sales_by_week(self, week: Optional[int] = None) -> List[Dict]:
        """Get sales data for specific week(s)"""
        if not self.use_cloud_sql:
            sales = self.data.get('sales_data', [])
            
            if week:
                return [s for s in sales if s.get('week_number') == week]
            else:
                return sales
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def compare_weeks(self, week1: int, week2: int) -> Dict:
        """Compare performance between two weeks"""
        if not self.use_cloud_sql:
            w1_sales = self.get_sales_by_week(week1)
            w2_sales = self.get_sales_by_week(week2)
            
            # Calculate metrics for each week
            w1_metrics = {
                'week': week1,
                'total_sales': sum(s['sale_amount'] for s in w1_sales),
                'total_units': sum(s['quantity_sold'] for s in w1_sales),
                'num_transactions': len(w1_sales)
            }
            
            w2_metrics = {
                'week': week2,
                'total_sales': sum(s['sale_amount'] for s in w2_sales),
                'total_units': sum(s['quantity_sold'] for s in w2_sales),
                'num_transactions': len(w2_sales)
            }
            
            # Calculate changes
            change = {
                'sales_change': w2_metrics['total_sales'] - w1_metrics['total_sales'],
                'sales_change_pct': ((w2_metrics['total_sales'] - w1_metrics['total_sales']) / w1_metrics['total_sales'] * 100) if w1_metrics['total_sales'] > 0 else 0,
                'units_change': w2_metrics['total_units'] - w1_metrics['total_units'],
                'units_change_pct': ((w2_metrics['total_units'] - w1_metrics['total_units']) / w1_metrics['total_units'] * 100) if w1_metrics['total_units'] > 0 else 0
            }
            
            return {
                'week1': w1_metrics,
                'week2': w2_metrics,
                'change': change
            }
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def get_sku_weekly_trend(self, sku_id: str, weeks: int = 5) -> Dict:
        """Get weekly sales trend for a specific SKU"""
        if not self.use_cloud_sql:
            current_week = self.get_current_week()
            start_week = max(1, current_week - weeks + 1)
            
            weekly_data = []
            for week in range(start_week, current_week + 1):
                week_sales = [s for s in self.get_sales_by_week(week) if s['sku_id'] == sku_id]
                
                weekly_data.append({
                    'week': week,
                    'units_sold': sum(s['quantity_sold'] for s in week_sales),
                    'revenue': sum(s['sale_amount'] for s in week_sales),
                    'transactions': len(week_sales)
                })
            
            return {
                'sku_id': sku_id,
                'weeks': weekly_data,
                'trend': self._calculate_trend(weekly_data)
            }
        else:
            # TODO: Query from Cloud SQL
            pass
    
    def _calculate_trend(self, weekly_data: List[Dict]) -> str:
        """Calculate if trend is improving, declining, or stable"""
        if len(weekly_data) < 2:
            return 'insufficient_data'
        
        # Compare first half vs second half
        mid = len(weekly_data) // 2
        first_half_avg = sum(w['units_sold'] for w in weekly_data[:mid]) / mid
        second_half_avg = sum(w['units_sold'] for w in weekly_data[mid:]) / (len(weekly_data) - mid)
        
        if second_half_avg > first_half_avg * 1.2:
            return 'improving'
        elif second_half_avg < first_half_avg * 0.8:
            return 'declining'
        else:
            return 'stable'
    
    # ============================================================================
    # SKU Management
    # ============================================================================
    
    def add_sku(self, sku_data: Dict) -> Dict:
        """Add a new SKU to inventory"""
        if not self.use_cloud_sql:
            skus = self.data.get('skus', [])
            
            # Auto-generate SKU ID if not provided
            if 'sku_id' not in sku_data:
                # Get highest number from existing SKUs
                max_num = 0
                for sku in skus:
                    try:
                        num = int(sku['sku_id'][-5:])
                        max_num = max(max_num, num)
                    except:
                        pass
                
                category_code = sku_data.get('category', 'GEN')[:3].upper()
                sku_data['sku_id'] = f"{category_code}{str(max_num + 1).zfill(5)}"
            
            # Set defaults
            sku_data.setdefault('arrival_date', datetime.now().strftime('%Y-%m-%d'))
            sku_data.setdefault('is_new_arrival', True)
            sku_data.setdefault('stock_quantity', 0)
            
            # Calculate margin if not provided
            if 'margin_percentage' not in sku_data and 'cost_price' in sku_data and 'selling_price' in sku_data:
                cost = sku_data['cost_price']
                price = sku_data['selling_price']
                sku_data['margin_percentage'] = round(((price - cost) / price) * 100, 2)
            
            # Add to data
            skus.append(sku_data)
            self.data['skus'] = skus
            self._save_mock_data()
            
            return {
                'success': True,
                'sku': sku_data,
                'message': f'SKU {sku_data["sku_id"]} added successfully'
            }
        else:
            # TODO: Insert into Cloud SQL
            pass
