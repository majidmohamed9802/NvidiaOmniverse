import React, { useState } from 'react';
import api from '../services/api';
import ThreeDViewer from './ThreeDViewer';

function DailyPlan() {
  const [focusArea, setFocusArea] = useState('Central Mannequin');
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const focusAreas = [
    'Central Mannequin',
    'Focus Table',
    'Accessories Corner'
  ];

  const generatePlan = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.generateDailyPlan(focusArea);
      setPlan(response);
    } catch (err) {
      setError('Failed to generate plan. Make sure the backend is running with GCP credentials configured.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.mainTitle}>Daily Display Operations</h2>
      <p style={styles.subtitle}>
        Generate an updated visual plan based on new arrivals and stock levels
      </p>

      {/* Focus Area Selection */}
      <div style={styles.controlSection}>
        <label style={styles.label}>Select Focus Area:</label>
        <div style={styles.buttonGroup}>
          {focusAreas.map(area => (
            <button
              key={area}
              style={{
                ...styles.areaButton,
                ...(focusArea === area ? styles.areaButtonActive : {})
              }}
              onClick={() => setFocusArea(area)}
            >
              {area}
            </button>
          ))}
        </div>

        <button
          style={styles.generateButton}
          onClick={generatePlan}
          disabled={loading}
        >
          {loading ? 'Generating...' : "Generate Today's Update Plan"}
        </button>
      </div>

      {error && (
        <div style={styles.errorBox}>
          <strong>Error:</strong> {error}
        </div>
      )}

      {/* 3D Viewer */}
      <div style={styles.viewerSection}>
        <h3 style={styles.sectionTitle}>Visual Preview</h3>
        <ThreeDViewer displayData={plan} />
      </div>

      {/* Generated Plan Display */}
      {plan && plan.message && (
        <div style={styles.planSection}>
          <h3 style={styles.sectionTitle}>Execution Brief</h3>
          <div style={styles.planContent}>
            {plan.message.split('\n').map((line, idx) => (
              <p key={idx} style={styles.planLine}>
                {line}
              </p>
            ))}
          </div>
          
          {plan.data && (
            <div style={styles.dataSection}>
              <h4 style={styles.dataTitle}>Supporting Data</h4>
              <details style={styles.details}>
                <summary style={styles.summary}>View Data Context</summary>
                <pre style={styles.dataContent}>
                  {JSON.stringify(plan.data, null, 2)}
                </pre>
              </details>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  mainTitle: {
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '10px',
    color: '#2d3748',
  },
  subtitle: {
    fontSize: '16px',
    color: '#718096',
    marginBottom: '30px',
  },
  controlSection: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    marginBottom: '20px',
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: '600',
    color: '#4a5568',
    marginBottom: '12px',
  },
  buttonGroup: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '10px',
    marginBottom: '20px',
  },
  areaButton: {
    padding: '10px 16px',
    border: '2px solid #cbd5e0',
    borderRadius: '6px',
    backgroundColor: '#fff',
    cursor: 'pointer',
    fontSize: '14px',
    color: '#4a5568',
    transition: 'all 0.2s',
  },
  areaButtonActive: {
    backgroundColor: '#4299e1',
    color: '#fff',
    borderColor: '#4299e1',
  },
  generateButton: {
    padding: '12px 24px',
    backgroundColor: '#48bb78',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    width: '100%',
    transition: 'background-color 0.2s',
  },
  errorBox: {
    padding: '15px',
    backgroundColor: '#fff5f5',
    border: '1px solid #fc8181',
    borderRadius: '6px',
    color: '#c53030',
    marginBottom: '20px',
  },
  viewerSection: {
    marginBottom: '20px',
  },
  sectionTitle: {
    fontSize: '20px',
    fontWeight: '600',
    marginBottom: '15px',
    color: '#2d3748',
  },
  planSection: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  planContent: {
    lineHeight: '1.8',
    color: '#2d3748',
  },
  planLine: {
    margin: '8px 0',
  },
  dataSection: {
    marginTop: '20px',
    paddingTop: '20px',
    borderTop: '1px solid #e2e8f0',
  },
  dataTitle: {
    fontSize: '16px',
    fontWeight: '600',
    marginBottom: '10px',
    color: '#4a5568',
  },
  details: {
    cursor: 'pointer',
  },
  summary: {
    padding: '10px',
    backgroundColor: '#edf2f7',
    borderRadius: '6px',
    fontWeight: '500',
    color: '#4a5568',
  },
  dataContent: {
    marginTop: '10px',
    padding: '15px',
    backgroundColor: '#2d3748',
    color: '#48bb78',
    borderRadius: '6px',
    fontSize: '12px',
    overflow: 'auto',
    maxHeight: '400px',
  },
};

export default DailyPlan;
