import React, { useState, useRef, useEffect } from 'react';
import api from '../services/api';

function DisplayImageEditor() {
  const [zone, setZone] = useState('Central Mannequin');
  const [baseImage, setBaseImage] = useState(null);
  const [currentImage, setCurrentImage] = useState(null);
  const [editHistory, setEditHistory] = useState([]);
  const [fullContext, setFullContext] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  const zones = [
    'Central Mannequin',
    'Focus Table',
    'Accessories Corner'
  ];

  const exampleCommands = [
    'Put the black dress on the left mannequin',
    'Change the wallpaper to a soft green color',
    'Add the gold necklace to the right mannequin',
    'Adjust the lighting to be warmer and more inviting',
    'Place the white shirt folded on the display table'
  ];

  useEffect(() => {
    loadSession();
  }, [zone]);

  const loadSession = async () => {
    try {
      const session = await api.getDisplaySession(zone);
      if (session.success) {
        setCurrentImage(session.current_image);
        setFullContext(session.full_context);
        setEditHistory(session.history || []);
      }
    } catch (err) {
      console.log('No existing session for this zone');
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const imageBase64 = event.target.result;
        setBaseImage(imageBase64);
        setCurrentImage(imageBase64);
        
        try {
          setIsProcessing(true);
          await api.uploadBaseImage(zone, imageBase64);
          setEditHistory([]);
          setFullContext('Empty display area with neutral background');
          setError(null);
        } catch (err) {
          setError('Failed to upload base image: ' + err.message);
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendCommand = async () => {
    if (!chatInput.trim()) return;
    if (!currentImage) {
      setError('Please upload a base image first');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const result = await api.editDisplayImage(zone, chatInput);
      
      if (result.success) {
        setCurrentImage(result.image);
        setEditHistory(result.history);
        setFullContext(result.full_context);
        setChatInput('');
      } else {
        setError(result.error || 'Failed to apply edit');
      }
    } catch (err) {
      setError('Error: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm('Reset display to original image? This will remove all edits.')) {
      return;
    }

    setIsProcessing(true);
    try {
      const result = await api.resetDisplayImage(zone);
      if (result.success) {
        setCurrentImage(result.image);
        setEditHistory([]);
        setFullContext(result.full_context);
        setError(null);
      } else {
        setError(result.error || 'Failed to reset');
      }
    } catch (err) {
      setError('Error: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const selectExampleCommand = (command) => {
    setChatInput(command);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.mainTitle}>Display Image Editor</h2>
      <p style={styles.subtitle}>
        Upload a base image and use natural language to iteratively edit your display
      </p>

      <div style={styles.controlSection}>
        <label style={styles.label}>Display Area:</label>
        <div style={styles.buttonGroup}>
          {zones.map(z => (
            <button
              key={z}
              style={{
                ...styles.zoneButton,
                ...(zone === z ? styles.zoneButtonActive : {})
              }}
              onClick={() => setZone(z)}
              disabled={isProcessing}
            >
              {z}
            </button>
          ))}
        </div>
      </div>

      {!currentImage && (
        <div style={styles.uploadSection}>
          <h3 style={styles.sectionTitle}>Step 1: Upload Base Image</h3>
          <p style={styles.instructions}>
            Upload a photo of your {zone} display area (empty or current state)
          </p>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            style={styles.fileInput}
          />
          <button
            style={styles.uploadButton}
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessing}
          >
            Choose Image
          </button>
        </div>
      )}

      {currentImage && (
        <>
          <div style={styles.imageSection}>
            <div style={styles.imageHeader}>
              <h3 style={styles.sectionTitle}>Current Display</h3>
              <button
                style={styles.resetButton}
                onClick={handleReset}
                disabled={isProcessing || editHistory.length === 0}
              >
                Reset to Original
              </button>
            </div>
            <div style={styles.imageContainer}>
              <img src={currentImage} alt={zone} style={styles.displayImage} />
            </div>
            {fullContext && (
              <div style={styles.contextDisplay}>
                <strong>Current State:</strong> {fullContext}
              </div>
            )}
          </div>

          <div style={styles.chatSection}>
            <h3 style={styles.sectionTitle}>Edit Commands</h3>
            
            <div style={styles.historyContainer}>
              {editHistory.length === 0 ? (
                <div style={styles.emptyHistory}>
                  No edits yet. Type a command below to start editing!
                </div>
              ) : (
                editHistory.map((edit, idx) => (
                  <div key={idx} style={styles.historyEntry}>
                    <div style={styles.historyCommand}>
                      <strong>You:</strong> {edit.command}
                    </div>
                    <div style={styles.historySummary}>
                      <strong>Applied:</strong> {edit.summary}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div style={styles.exampleSection}>
              <p style={styles.exampleTitle}>Try these examples:</p>
              <div style={styles.exampleButtons}>
                {exampleCommands.map((cmd, idx) => (
                  <button
                    key={idx}
                    style={styles.exampleButton}
                    onClick={() => selectExampleCommand(cmd)}
                    disabled={isProcessing}
                  >
                    {cmd}
                  </button>
                ))}
              </div>
            </div>

            <div style={styles.inputSection}>
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendCommand()}
                placeholder="Describe what you want to change..."
                style={styles.chatInput}
                disabled={isProcessing}
              />
              <button
                style={styles.sendButton}
                onClick={handleSendCommand}
                disabled={isProcessing || !chatInput.trim()}
              >
                {isProcessing ? 'Processing...' : 'Apply Edit'}
              </button>
            </div>
          </div>

          {error && (
            <div style={styles.errorBox}>
              <strong>Error:</strong> {error}
            </div>
          )}
        </>
      )}
    </div>
  );
}

const styles = {
  container: { padding: '20px', maxWidth: '1200px', margin: '0 auto' },
  mainTitle: { fontSize: '28px', fontWeight: 'bold', marginBottom: '10px', color: '#2d3748' },
  subtitle: { fontSize: '16px', color: '#718096', marginBottom: '30px' },
  controlSection: { backgroundColor: '#fff', padding: '20px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', marginBottom: '20px' },
  label: { display: 'block', fontSize: '14px', fontWeight: '600', color: '#4a5568', marginBottom: '12px' },
  buttonGroup: { display: 'flex', flexWrap: 'wrap', gap: '10px' },
  zoneButton: { padding: '10px 16px', border: '2px solid #cbd5e0', borderRadius: '6px', backgroundColor: '#fff', cursor: 'pointer', fontSize: '14px', color: '#4a5568', transition: 'all 0.2s' },
  zoneButtonActive: { backgroundColor: '#4299e1', color: '#fff', borderColor: '#4299e1' },
  uploadSection: { backgroundColor: '#fff', padding: '40px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', textAlign: 'center' },
  sectionTitle: { fontSize: '20px', fontWeight: '600', marginBottom: '15px', color: '#2d3748' },
  instructions: { fontSize: '14px', color: '#718096', marginBottom: '20px' },
  fileInput: { display: 'none' },
  uploadButton: { padding: '12px 24px', backgroundColor: '#48bb78', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '16px', fontWeight: '600', cursor: 'pointer' },
  imageSection: { backgroundColor: '#fff', padding: '20px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', marginBottom: '20px' },
  imageHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' },
  resetButton: { padding: '8px 16px', backgroundColor: '#e53e3e', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' },
  imageContainer: { width: '100%', backgroundColor: '#f7fafc', borderRadius: '8px', overflow: 'hidden', marginBottom: '15px' },
  displayImage: { width: '100%', height: 'auto', display: 'block' },
  contextDisplay: { padding: '12px', backgroundColor: '#edf2f7', borderRadius: '6px', fontSize: '14px', color: '#4a5568' },
  chatSection: { backgroundColor: '#fff', padding: '20px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', marginBottom: '20px' },
  historyContainer: { maxHeight: '300px', overflowY: 'auto', marginBottom: '20px', padding: '15px', backgroundColor: '#f7fafc', borderRadius: '6px' },
  emptyHistory: { textAlign: 'center', color: '#a0aec0', padding: '20px', fontSize: '14px' },
  historyEntry: { marginBottom: '15px', padding: '12px', backgroundColor: '#fff', borderRadius: '6px', borderLeft: '3px solid #4299e1' },
  historyCommand: { fontSize: '14px', color: '#2d3748', marginBottom: '5px' },
  historySummary: { fontSize: '13px', color: '#718096' },
  exampleSection: { marginBottom: '20px' },
  exampleTitle: { fontSize: '13px', color: '#718096', marginBottom: '10px' },
  exampleButtons: { display: 'flex', flexDirection: 'column', gap: '8px' },
  exampleButton: { padding: '10px', backgroundColor: '#edf2f7', border: '1px solid #cbd5e0', borderRadius: '6px', fontSize: '13px', color: '#4a5568', cursor: 'pointer', textAlign: 'left', transition: 'background-color 0.2s' },
  inputSection: { display: 'flex', gap: '10px' },
  chatInput: { flex: 1, padding: '12px', border: '1px solid #cbd5e0', borderRadius: '6px', fontSize: '14px', color: '#2d3748' },
  sendButton: { padding: '12px 24px', backgroundColor: '#4299e1', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '600', cursor: 'pointer', whiteSpace: 'nowrap' },
  errorBox: { padding: '15px', backgroundColor: '#fff5f5', border: '1px solid #fc8181', borderRadius: '6px', color: '#c53030', marginBottom: '20px' },
};

export default DisplayImageEditor;
