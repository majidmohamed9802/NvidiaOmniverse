import React, { useState, useEffect } from 'react';
import api from '../services/api';

function AnalyticsDashboard() {
  const [topPerformers, setTopPerformers] = useState([]);
  const [slowMovers, setSlowMovers] = useState([]);
  const [zonePerformance, setZonePerformance] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const [performers, slow, zones] = await Promise.all([
        api.getTopPerformers(10, 30),
        api.getSlowMovers(),
        api.getZonePerformance(30)
      ]);

      setTopPerformers(performers);
      setSlowMovers(slow);
      setZonePerformance(zones);
      setError(null);
    } catch (err) {
      setError('Failed to load analytics data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div style={styles.loading}>Loading analytics...</div>;
  }

  if (error) {
    return <div style={styles.error}>{error}</div>;
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.mainTitle}>Analytics Dashboard</h2>

      {/* Top Performers */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Top SKU Performance (Last 30 Days)</h3>
        <table style={styles.table}>
          <thead>
            <tr style={styles.tableHeader}>
              <th style={styles.th}>SKU ID</th>
              <th style={styles.th}>Product Name</th>
              <th style={styles.th}>Category</th>
              <th style={styles.th}>Units Sold</th>
              <th style={styles.th}>Revenue</th>
            </tr>
          </thead>
          <tbody>
            {topPerformers.map((item, idx) => (
              <tr key={idx} style={idx % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd}>
                <td style={styles.td}>{item.sku_id}</td>
                <td style={styles.td}>{item.product_name}</td>
                <td style={styles.td}>{item.category}</td>
                <td style={styles.td}>{item.units_sold}</td>
                <td style={styles.td}>${item.revenue.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Zone Performance */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Sales by Zone (Last 30 Days)</h3>
        <div style={styles.cardGrid}>
          {zonePerformance
            .sort((a, b) => b.revenue - a.revenue)
            .map((zone, idx) => (
              <div key={idx} style={styles.card}>
                <div style={styles.cardTitle}>{zone.zone}</div>
                <div style={styles.cardMetric}>${zone.revenue.toFixed(2)}</div>
                <div style={styles.cardSubtext}>{zone.units_sold} units sold</div>
              </div>
            ))}
        </div>
      </div>

      {/* Slow Movers */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Slow Movers ({slowMovers.length} items)</h3>
        <div style={styles.slowMoversGrid}>
          {slowMovers.slice(0, 6).map((item, idx) => (
            <div key={idx} style={styles.slowMoverCard}>
              <div style={styles.slowMoverSku}>{item.sku_id}</div>
              <div style={styles.slowMoverDays}>{item.days_without_sale} days without sale</div>
              <div style={styles.slowMoverStock}>{item.stock_quantity} units in stock</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  loading: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#718096',
  },
  error: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#e53e3e',
  },
  mainTitle: {
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '30px',
    color: '#2d3748',
  },
  section: {
    marginBottom: '40px',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  sectionTitle: {
    fontSize: '20px',
    fontWeight: '600',
    marginBottom: '20px',
    color: '#2d3748',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  tableHeader: {
    backgroundColor: '#edf2f7',
  },
  th: {
    padding: '12px',
    textAlign: 'left',
    fontWeight: '600',
    color: '#4a5568',
    borderBottom: '2px solid #cbd5e0',
  },
  td: {
    padding: '12px',
    borderBottom: '1px solid #e2e8f0',
    color: '#2d3748',
  },
  tableRowEven: {
    backgroundColor: '#fff',
  },
  tableRowOdd: {
    backgroundColor: '#f7fafc',
  },
  cardGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '15px',
  },
  card: {
    padding: '20px',
    backgroundColor: '#edf2f7',
    borderRadius: '8px',
    textAlign: 'center',
  },
  cardTitle: {
    fontSize: '14px',
    color: '#718096',
    marginBottom: '10px',
    fontWeight: '500',
  },
  cardMetric: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#2d3748',
    marginBottom: '5px',
  },
  cardSubtext: {
    fontSize: '12px',
    color: '#a0aec0',
  },
  slowMoversGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '12px',
  },
  slowMoverCard: {
    padding: '15px',
    backgroundColor: '#fff5f5',
    border: '1px solid #feb2b2',
    borderRadius: '6px',
  },
  slowMoverSku: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#c53030',
    marginBottom: '8px',
  },
  slowMoverDays: {
    fontSize: '13px',
    color: '#742a2a',
    marginBottom: '4px',
  },
  slowMoverStock: {
    fontSize: '12px',
    color: '#9b2c2c',
  },
};

export default AnalyticsDashboard;
