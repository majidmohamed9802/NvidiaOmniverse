import React, { useState } from 'react';
import api from '../services/api';

function AddSKU() {
  const [formData, setFormData] = useState({
    product_name: '',
    category: 'Apparel',
    sub_category: '',
    brand: '',
    color: '',
    size: '',
    cost_price: '',
    selling_price: '',
    stock_quantity: '',
    season: 'All Season'
  });
  
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    setError(null);

    try {
      // Convert prices to numbers
      const skuData = {
        ...formData,
        cost_price: parseFloat(formData.cost_price),
        selling_price: parseFloat(formData.selling_price),
        stock_quantity: parseInt(formData.stock_quantity) || 0
      };

      const result = await api.addSKU(skuData);
      
      setMessage(result.message);
      
      // Reset form
      setFormData({
        product_name: '',
        category: 'Apparel',
        sub_category: '',
        brand: '',
        color: '',
        size: '',
        cost_price: '',
        selling_price: '',
        stock_quantity: '',
        season: 'All Season'
      });
    } catch (err) {
      setError(err.message || 'Failed to add SKU');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['Apparel', 'Accessories', 'Footwear', 'Home', 'Beauty'];
  const seasons = ['Spring/Summer', 'Fall/Winter', 'All Season'];

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Add New SKU</h2>

      {message && (
        <div style={styles.successMessage}>{message}</div>
      )}

      {error && (
        <div style={styles.errorMessage}>{error}</div>
      )}

      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.row}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Product Name *</label>
            <input
              type="text"
              name="product_name"
              value={formData.product_name}
              onChange={handleChange}
              required
              style={styles.input}
              placeholder="e.g. Summer Cotton Dress"
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Brand</label>
            <input
              type="text"
              name="brand"
              value={formData.brand}
              onChange={handleChange}
              style={styles.input}
              placeholder="e.g. Fashion Brand"
            />
          </div>
        </div>

        <div style={styles.row}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Category *</label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
              style={styles.select}
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Sub-Category</label>
            <input
              type="text"
              name="sub_category"
              value={formData.sub_category}
              onChange={handleChange}
              style={styles.input}
              placeholder="e.g. Dresses, Shirts"
            />
          </div>
        </div>

        <div style={styles.row}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Color</label>
            <input
              type="text"
              name="color"
              value={formData.color}
              onChange={handleChange}
              style={styles.input}
              placeholder="e.g. Navy Blue"
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Size</label>
            <input
              type="text"
              name="size"
              value={formData.size}
              onChange={handleChange}
              style={styles.input}
              placeholder="e.g. M, L, ONE SIZE"
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Season</label>
            <select
              name="season"
              value={formData.season}
              onChange={handleChange}
              style={styles.select}
            >
              {seasons.map(season => (
                <option key={season} value={season}>{season}</option>
              ))}
            </select>
          </div>
        </div>

        <div style={styles.row}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Cost Price *</label>
            <input
              type="number"
              step="0.01"
              name="cost_price"
              value={formData.cost_price}
              onChange={handleChange}
              required
              style={styles.input}
              placeholder="0.00"
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Selling Price *</label>
            <input
              type="number"
              step="0.01"
              name="selling_price"
              value={formData.selling_price}
              onChange={handleChange}
              required
              style={styles.input}
              placeholder="0.00"
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Stock Quantity</label>
            <input
              type="number"
              name="stock_quantity"
              value={formData.stock_quantity}
              onChange={handleChange}
              style={styles.input}
              placeholder="0"
            />
          </div>
        </div>

        {formData.cost_price && formData.selling_price && (
          <div style={styles.marginInfo}>
            <strong>Margin: </strong>
            {(((parseFloat(formData.selling_price) - parseFloat(formData.cost_price)) / parseFloat(formData.selling_price)) * 100).toFixed(2)}%
          </div>
        )}

        <button 
          type="submit" 
          disabled={loading}
          style={{
            ...styles.submitButton,
            ...(loading ? styles.submitButtonDisabled : {})
          }}
        >
          {loading ? 'Adding SKU...' : 'Add SKU'}
        </button>
      </form>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '900px',
    margin: '0 auto',
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '30px',
    color: '#2d3748',
  },
  form: {
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  row: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '20px',
    marginBottom: '20px',
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
  },
  label: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#4a5568',
    marginBottom: '8px',
  },
  input: {
    padding: '10px 12px',
    fontSize: '14px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    outline: 'none',
    transition: 'border-color 0.2s',
  },
  select: {
    padding: '10px 12px',
    fontSize: '14px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    outline: 'none',
    backgroundColor: '#fff',
    cursor: 'pointer',
  },
  marginInfo: {
    padding: '12px',
    backgroundColor: '#edf2f7',
    borderRadius: '6px',
    marginBottom: '20px',
    fontSize: '14px',
    color: '#2d3748',
  },
  submitButton: {
    width: '100%',
    padding: '14px',
    fontSize: '16px',
    fontWeight: '600',
    color: '#fff',
    backgroundColor: '#4299e1',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  submitButtonDisabled: {
    backgroundColor: '#a0aec0',
    cursor: 'not-allowed',
  },
  successMessage: {
    padding: '12px',
    backgroundColor: '#c6f6d5',
    border: '1px solid #9ae6b4',
    borderRadius: '6px',
    color: '#22543d',
    marginBottom: '20px',
  },
  errorMessage: {
    padding: '12px',
    backgroundColor: '#fed7d7',
    border: '1px solid #fc8181',
    borderRadius: '6px',
    color: '#742a2a',
    marginBottom: '20px',
  },
};

export default AddSKU;
