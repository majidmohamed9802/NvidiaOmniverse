import React from 'react';

/**
 * 3D Viewer Placeholder Component
 * This is a placeholder that will be replaced with Nvidia Omniverse integration
 */
function ThreeDViewer({ displayData, onSceneUpdate }) {
  return (
    <div style={styles.container}>
      <div style={styles.placeholder}>
        <div style={styles.iconContainer}>
          <svg width="100" height="100" viewBox="0 0 100 100" fill="none">
            <rect x="20" y="30" width="60" height="40" fill="#4A5568" stroke="#718096" strokeWidth="2"/>
            <rect x="15" y="35" width="60" height="40" fill="#2D3748" stroke="#4A5568" strokeWidth="2"/>
            <rect x="10" y="40" width="60" height="40" fill="#1A202C" stroke="#2D3748" strokeWidth="2"/>
            <circle cx="40" cy="60" r="8" fill="#48BB78"/>
            <circle cx="55" cy="55" r="6" fill="#4299E1"/>
          </svg>
        </div>
        <h3 style={styles.title}>3D Store Viewer</h3>
        <p style={styles.subtitle}>Nvidia Omniverse Integration Ready</p>
        <div style={styles.infoBox}>
          <p style={styles.infoText}>
            This component is prepared for Nvidia Omniverse API integration.
          </p>
          <p style={styles.infoText}>
            Once connected, you'll be able to:
          </p>
          <ul style={styles.featureList}>
            <li>View 3D store layouts</li>
            <li>Interact with display elements</li>
            <li>Modify scenes via natural language</li>
            <li>Preview merchandising changes in real-time</li>
          </ul>
        </div>
        {displayData && (
          <div style={styles.dataPreview}>
            <strong>Display Data Received:</strong>
            <pre style={styles.dataText}>
              {JSON.stringify(displayData, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    width: '100%',
    height: '500px',
    backgroundColor: '#f7fafc',
    border: '2px dashed #cbd5e0',
    borderRadius: '8px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
  },
  placeholder: {
    textAlign: 'center',
    maxWidth: '600px',
  },
  iconContainer: {
    marginBottom: '20px',
    display: 'flex',
    justifyContent: 'center',
  },
  title: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#2d3748',
    marginBottom: '8px',
  },
  subtitle: {
    fontSize: '16px',
    color: '#718096',
    marginBottom: '20px',
  },
  infoBox: {
    backgroundColor: '#edf2f7',
    padding: '20px',
    borderRadius: '8px',
    marginTop: '20px',
    textAlign: 'left',
  },
  infoText: {
    color: '#4a5568',
    marginBottom: '10px',
    fontSize: '14px',
  },
  featureList: {
    color: '#4a5568',
    marginLeft: '20px',
    fontSize: '14px',
    lineHeight: '1.8',
  },
  dataPreview: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#2d3748',
    borderRadius: '8px',
    textAlign: 'left',
    maxHeight: '200px',
    overflow: 'auto',
  },
  dataText: {
    color: '#48bb78',
    fontSize: '12px',
    margin: '10px 0 0 0',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
  },
};

export default ThreeDViewer;
