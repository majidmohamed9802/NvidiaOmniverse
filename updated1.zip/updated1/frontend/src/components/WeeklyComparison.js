import React, { useState, useEffect } from 'react';
import api from '../services/api';

function WeeklyComparison() {
  const [currentWeek, setCurrentWeek] = useState(5);
  const [week1, setWeek1] = useState(4);
  const [week2, setWeek2] = useState(5);
  const [comparison, setComparison] = useState(null);
  const [selectedSKU, setSelectedSKU] = useState('');
  const [skuTrend, setSkuTrend] = useState(null);
  const [skus, setSkus] = useState([]);
  const [loading, setLoading] = useState(false);
  const [aiInsights, setAiInsights] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [weekData, skuData] = await Promise.all([
        api.getCurrentWeek(),
        api.getSKUs()
      ]);
      
      setCurrentWeek(weekData.current_week);
      setWeek1(Math.max(1, weekData.current_week - 1));
      setWeek2(weekData.current_week);
      setSkus(skuData);
      
      // Auto-load comparison
      await loadComparison(Math.max(1, weekData.current_week - 1), weekData.current_week);
    } catch (err) {
      console.error('Error loading data:', err);
    }
  };

  const loadComparison = async (w1, w2) => {
    setLoading(true);
    try {
      const data = await api.compareWeeks(w1, w2);
      setComparison(data);
      
      // Get AI insights
      await getAIInsights(data);
    } catch (err) {
      console.error('Error loading comparison:', err);
    } finally {
      setLoading(false);
    }
  };

  const getAIInsights = async (comparisonData) => {
    try {
      const insights = await api.getWeeklyInsights(comparisonData);
      setAiInsights(insights);
    } catch (err) {
      console.error('Error getting AI insights:', err);
    }
  };

  const handleCompare = () => {
    loadComparison(week1, week2);
  };

  const handleSKUSelect = async (e) => {
    const sku = e.target.value;
    setSelectedSKU(sku);
    
    if (sku) {
      try {
        const trend = await api.getSKUTrend(sku, 5);
        setSkuTrend(trend);
      } catch (err) {
        console.error('Error loading SKU trend:', err);
      }
    } else {
      setSkuTrend(null);
    }
  };

  const advanceWeek = async () => {
    if (window.confirm(`Advance from Week ${currentWeek} to Week ${currentWeek + 1}?`)) {
      try {
        const result = await api.advanceWeek();
        alert(result.message);
        loadData();
      } catch (err) {
        alert('Error advancing week: ' + err.message);
      }
    }
  };

  if (loading && !comparison) {
    return <div style={styles.loading}>Loading comparison...</div>;
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={styles.title}>Weekly Performance Tracking</h2>
        <div style={styles.weekBadge}>
          Current Week: {currentWeek}
        </div>
        <button onClick={advanceWeek} style={styles.advanceButton}>
          Advance to Week {currentWeek + 1} →
        </button>
      </div>

      {/* Week Comparison Selector */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Compare Weeks</h3>
        <div style={styles.comparisonControls}>
          <div>
            <label style={styles.label}>Week 1:</label>
            <select value={week1} onChange={(e) => setWeek1(parseInt(e.target.value))} style={styles.select}>
              {[...Array(currentWeek)].map((_, i) => (
                <option key={i + 1} value={i + 1}>Week {i + 1}</option>
              ))}
            </select>
          </div>
          <div>
            <label style={styles.label}>Week 2:</label>
            <select value={week2} onChange={(e) => setWeek2(parseInt(e.target.value))} style={styles.select}>
              {[...Array(currentWeek)].map((_, i) => (
                <option key={i + 1} value={i + 1}>Week {i + 1}</option>
              ))}
            </select>
          </div>
          <button onClick={handleCompare} style={styles.compareButton}>
            Compare
          </button>
        </div>
      </div>

      {/* Comparison Results */}
      {comparison && (
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Week {week1} vs Week {week2}</h3>
          <div style={styles.metricsGrid}>
            <div style={styles.metricCard}>
              <div style={styles.metricLabel}>Total Sales</div>
              <div style={styles.metricValue}>
                ${comparison.week2.total_sales.toFixed(2)}
              </div>
              <div style={{
                ...styles.metricChange,
                color: comparison.change.sales_change >= 0 ? '#38a169' : '#e53e3e'
              }}>
                {comparison.change.sales_change >= 0 ? '↑' : '↓'} 
                {Math.abs(comparison.change.sales_change_pct).toFixed(1)}%
                (${Math.abs(comparison.change.sales_change).toFixed(2)})
              </div>
            </div>

            <div style={styles.metricCard}>
              <div style={styles.metricLabel}>Units Sold</div>
              <div style={styles.metricValue}>
                {comparison.week2.total_units}
              </div>
              <div style={{
                ...styles.metricChange,
                color: comparison.change.units_change >= 0 ? '#38a169' : '#e53e3e'
              }}>
                {comparison.change.units_change >= 0 ? '↑' : '↓'} 
                {Math.abs(comparison.change.units_change_pct).toFixed(1)}%
                ({Math.abs(comparison.change.units_change)} units)
              </div>
            </div>

            <div style={styles.metricCard}>
              <div style={styles.metricLabel}>Transactions</div>
              <div style={styles.metricValue}>
                {comparison.week2.num_transactions}
              </div>
              <div style={styles.metricChange}>
                Week {week1}: {comparison.week1.num_transactions}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI Insights */}
      {aiInsights && (
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>🤖 AI Insights</h3>
          <div style={styles.insightsBox}>
            {aiInsights.message}
          </div>
        </div>
      )}

      {/* SKU Trend Analysis */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>SKU Weekly Trend</h3>
        <select value={selectedSKU} onChange={handleSKUSelect} style={styles.select}>
          <option value="">Select a SKU...</option>
          {skus.map(sku => (
            <option key={sku.sku_id} value={sku.sku_id}>
              {sku.sku_id} - {sku.product_name}
            </option>
          ))}
        </select>

        {skuTrend && (
          <div style={styles.trendContainer}>
            <div style={styles.trendBadge}>
              Trend: <strong>{skuTrend.trend.toUpperCase()}</strong>
            </div>
            <table style={styles.table}>
              <thead>
                <tr style={styles.tableHeader}>
                  <th style={styles.th}>Week</th>
                  <th style={styles.th}>Units Sold</th>
                  <th style={styles.th}>Revenue</th>
                  <th style={styles.th}>Transactions</th>
                </tr>
              </thead>
              <tbody>
                {skuTrend.weeks.map((week, idx) => (
                  <tr key={week.week} style={idx % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd}>
                    <td style={styles.td}>Week {week.week}</td>
                    <td style={styles.td}>{week.units_sold}</td>
                    <td style={styles.td}>${week.revenue.toFixed(2)}</td>
                    <td style={styles.td}>{week.transactions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '30px',
    flexWrap: 'wrap',
    gap: '15px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#2d3748',
  },
  weekBadge: {
    padding: '10px 20px',
    backgroundColor: '#4299e1',
    color: '#fff',
    borderRadius: '20px',
    fontWeight: '600',
    fontSize: '16px',
  },
  advanceButton: {
    padding: '10px 20px',
    backgroundColor: '#48bb78',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
  },
  loading: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#718096',
  },
  section: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    marginBottom: '20px',
  },
  sectionTitle: {
    fontSize: '20px',
    fontWeight: '600',
    marginBottom: '20px',
    color: '#2d3748',
  },
  comparisonControls: {
    display: 'flex',
    gap: '20px',
    alignItems: 'flex-end',
    flexWrap: 'wrap',
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: '600',
    color: '#4a5568',
    marginBottom: '8px',
  },
  select: {
    padding: '10px 12px',
    fontSize: '14px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    minWidth: '150px',
  },
  compareButton: {
    padding: '10px 24px',
    backgroundColor: '#4299e1',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
  },
  metricsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '20px',
  },
  metricCard: {
    padding: '20px',
    backgroundColor: '#f7fafc',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  metricLabel: {
    fontSize: '14px',
    color: '#718096',
    marginBottom: '8px',
  },
  metricValue: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#2d3748',
    marginBottom: '8px',
  },
  metricChange: {
    fontSize: '14px',
    fontWeight: '600',
  },
  insightsBox: {
    padding: '20px',
    backgroundColor: '#ebf8ff',
    borderRadius: '8px',
    border: '1px solid #90cdf4',
    lineHeight: '1.6',
    color: '#2c5282',
    whiteSpace: 'pre-wrap',
  },
  trendContainer: {
    marginTop: '20px',
  },
  trendBadge: {
    display: 'inline-block',
    padding: '8px 16px',
    backgroundColor: '#edf2f7',
    borderRadius: '6px',
    marginBottom: '15px',
    fontSize: '14px',
    color: '#2d3748',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  tableHeader: {
    backgroundColor: '#edf2f7',
  },
  th: {
    padding: '12px',
    textAlign: 'left',
    fontWeight: '600',
    color: '#4a5568',
    borderBottom: '2px solid #cbd5e0',
  },
  td: {
    padding: '12px',
    borderBottom: '1px solid #e2e8f0',
    color: '#2d3748',
  },
  tableRowEven: {
    backgroundColor: '#fff',
  },
  tableRowOdd: {
    backgroundColor: '#f7fafc',
  },
};

export default WeeklyComparison;
