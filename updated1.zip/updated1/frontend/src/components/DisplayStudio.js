import React, { useState } from 'react';
import api from '../services/api';
import ThreeDViewer from './ThreeDViewer';

function DisplayStudio() {
  const [prompt, setPrompt] = useState('');
  const [zone, setZone] = useState('Central Mannequin');
  const [display, setDisplay] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const zones = [
    'Central Mannequin',
    'Central Mannequin',
    'Focus Table',
    'Perimeter Wall',
    'Accessories Corner'
  ];

  const examplePrompts = [
    'Create a captivating window display featuring our luxurious cashmere collection with warm autumn tones',
    'Design a casual weekend retreat display with comfortable loungewear and cozy accessories',
    'Showcase new arrivals with a modern minimalist aesthetic'
  ];

  const createDisplay = async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const response = await api.createDisplay(prompt, zone);
      setDisplay(response);
    } catch (err) {
      setError('Failed to create display. Make sure the backend is running with GCP credentials configured.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const selectExamplePrompt = (examplePrompt) => {
    setPrompt(examplePrompt);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.mainTitle}>Visual Merchandising Studio</h2>
      <p style={styles.subtitle}>
        Describe your display concept and let AI create a comprehensive execution plan
      </p>

      {/* Input Section */}
      <div style={styles.inputSection}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Display Zone:</label>
          <select
            value={zone}
            onChange={(e) => setZone(e.target.value)}
            style={styles.select}
          >
            {zones.map(z => (
              <option key={z} value={z}>{z}</option>
            ))}
          </select>
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Display Concept:</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the display you want to create..."
            style={styles.textarea}
            rows={4}
          />
        </div>

        <div style={styles.exampleSection}>
          <p style={styles.exampleTitle}>Try an example:</p>
          <div style={styles.exampleButtons}>
            {examplePrompts.map((example, idx) => (
              <button
                key={idx}
                style={styles.exampleButton}
                onClick={() => selectExamplePrompt(example)}
              >
                {example.substring(0, 60)}...
              </button>
            ))}
          </div>
        </div>

        <button
          style={styles.createButton}
          onClick={createDisplay}
          disabled={loading}
        >
          {loading ? 'Creating Display...' : 'Generate Display Plan'}
        </button>
      </div>

      {error && (
        <div style={styles.errorBox}>
          <strong>Error:</strong> {error}
        </div>
      )}

      {/* 3D Viewer */}
      {display && (
        <>
          <div style={styles.viewerSection}>
            <h3 style={styles.sectionTitle}>Visual Preview</h3>
            <ThreeDViewer displayData={display} />
          </div>

          {/* Display Plan */}
          <div style={styles.planSection}>
            <h3 style={styles.sectionTitle}>Display Execution Plan</h3>
            <div style={styles.planContent}>
              {display.message && display.message.split('\n').map((line, idx) => (
                <p key={idx} style={styles.planLine}>
                  {line}
                </p>
              ))}
            </div>

            {display.context && (
              <div style={styles.contextSection}>
                <h4 style={styles.contextTitle}>Supporting Context</h4>
                <details style={styles.details}>
                  <summary style={styles.summary}>View Context Data</summary>
                  <pre style={styles.contextContent}>
                    {JSON.stringify(display.context, null, 2)}
                  </pre>
                </details>
              </div>
            )}

            <div style={styles.actionButtons}>
              <button style={styles.actionButton}>
                Download as PDF
              </button>
              <button style={styles.actionButton}>
                Save to Team
              </button>
              <button style={styles.actionButtonSecondary}>
                Regenerate Plan
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  mainTitle: {
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '10px',
    color: '#2d3748',
  },
  subtitle: {
    fontSize: '16px',
    color: '#718096',
    marginBottom: '30px',
  },
  inputSection: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    marginBottom: '20px',
  },
  formGroup: {
    marginBottom: '20px',
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: '600',
    color: '#4a5568',
    marginBottom: '8px',
  },
  select: {
    width: '100%',
    padding: '10px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    fontSize: '14px',
    color: '#2d3748',
  },
  textarea: {
    width: '100%',
    padding: '12px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    fontSize: '14px',
    color: '#2d3748',
    fontFamily: 'inherit',
    resize: 'vertical',
  },
  exampleSection: {
    marginBottom: '20px',
  },
  exampleTitle: {
    fontSize: '13px',
    color: '#718096',
    marginBottom: '10px',
  },
  exampleButtons: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
  },
  exampleButton: {
    padding: '10px',
    backgroundColor: '#edf2f7',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    fontSize: '13px',
    color: '#4a5568',
    cursor: 'pointer',
    textAlign: 'left',
    transition: 'background-color 0.2s',
  },
  createButton: {
    padding: '12px 24px',
    backgroundColor: '#4299e1',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    width: '100%',
    transition: 'background-color 0.2s',
  },
  errorBox: {
    padding: '15px',
    backgroundColor: '#fff5f5',
    border: '1px solid #fc8181',
    borderRadius: '6px',
    color: '#c53030',
    marginBottom: '20px',
  },
  viewerSection: {
    marginBottom: '20px',
  },
  sectionTitle: {
    fontSize: '20px',
    fontWeight: '600',
    marginBottom: '15px',
    color: '#2d3748',
  },
  planSection: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  planContent: {
    lineHeight: '1.8',
    color: '#2d3748',
    marginBottom: '20px',
  },
  planLine: {
    margin: '8px 0',
  },
  contextSection: {
    marginTop: '20px',
    paddingTop: '20px',
    borderTop: '1px solid #e2e8f0',
  },
  contextTitle: {
    fontSize: '16px',
    fontWeight: '600',
    marginBottom: '10px',
    color: '#4a5568',
  },
  details: {
    cursor: 'pointer',
  },
  summary: {
    padding: '10px',
    backgroundColor: '#edf2f7',
    borderRadius: '6px',
    fontWeight: '500',
    color: '#4a5568',
  },
  contextContent: {
    marginTop: '10px',
    padding: '15px',
    backgroundColor: '#2d3748',
    color: '#48bb78',
    borderRadius: '6px',
    fontSize: '12px',
    overflow: 'auto',
    maxHeight: '400px',
  },
  actionButtons: {
    display: 'flex',
    gap: '10px',
    marginTop: '20px',
  },
  actionButton: {
    padding: '10px 20px',
    backgroundColor: '#48bb78',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
  },
  actionButtonSecondary: {
    padding: '10px 20px',
    backgroundColor: '#fff',
    color: '#4a5568',
    border: '2px solid #cbd5e0',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
  },
};

export default DisplayStudio;
