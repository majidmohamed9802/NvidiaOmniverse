import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import api from '../services/api';

function Analytics() {
  const [currentWeek, setCurrentWeek] = useState(5);
  const [week1, setWeek1] = useState(4);
  const [week2, setWeek2] = useState(5);
  const [comparison, setComparison] = useState(null);
  const [selectedSKU, setSelectedSKU] = useState('');
  const [skuTrend, setSkuTrend] = useState(null);
  const [skus, setSkus] = useState([]);
  const [loading, setLoading] = useState(false);
  const [aiInsights, setAiInsights] = useState(null);
  const [allSKUsTrends, setAllSKUsTrends] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [weekData, skuData] = await Promise.all([
        api.getCurrentWeek(),
        api.getSKUs()
      ]);
      
      setCurrentWeek(weekData.current_week);
      setWeek1(Math.max(1, weekData.current_week - 1));
      setWeek2(weekData.current_week);
      setSkus(skuData);
      
      // Auto-load comparison
      await loadComparison(Math.max(1, weekData.current_week - 1), weekData.current_week);
      
      // Load all SKU trends for charts
      await loadAllSKUTrends(skuData);
    } catch (err) {
      console.error('Error loading data:', err);
    }
  };

  const loadAllSKUTrends = async (skuList) => {
    try {
      const trends = await Promise.all(
        skuList.map(async (sku) => {
          try {
            const trend = await api.getSKUTrend(sku.sku_id, 5);
            return {
              sku_id: sku.sku_id,
              product_name: sku.product_name,
              ...trend
            };
          } catch (err) {
            console.error(`Error loading trend for ${sku.sku_id}:`, err);
            return null;
          }
        })
      );
      setAllSKUsTrends(trends.filter(t => t !== null));
    } catch (err) {
      console.error('Error loading SKU trends:', err);
    }
  };

  const loadComparison = async (w1, w2) => {
    setLoading(true);
    try {
      const data = await api.compareWeeks(w1, w2);
      setComparison(data);
      
      // Get AI insights with actionable recommendations
      await getAIInsights(data);
    } catch (err) {
      console.error('Error loading comparison:', err);
    } finally {
      setLoading(false);
    }
  };

  const getAIInsights = async (comparisonData) => {
    try {
      const insights = await api.getEnhancedWeeklyInsights(comparisonData, skus);
      setAiInsights(insights);
    } catch (err) {
      console.error('Error getting AI insights:', err);
      
      // Show quota exceeded message
      setAiInsights({
        message: '⚠️ AI Insights Unavailable\n\nUnable to generate insights due to API quota limits. Please check your Google Cloud Platform quotas and billing settings.\n\nThe AI insights feature will automatically work once your quota is restored.',
        actions: [],
        isError: true
      });
    }
  };

  const generateMockInsights = (comparisonData, skuList) => {
    const changePercent = comparisonData?.change?.sales_change_pct || 0;
    const unitsChange = comparisonData?.change?.units_change || 0;
    
    // Generate dynamic insights based on actual data
    let message = `Performance Analysis:\n\n`;
    
    if (changePercent > 10) {
      message += `📈 Strong performance with ${changePercent.toFixed(1)}% increase in sales. `;
    } else if (changePercent > 0) {
      message += `📊 Moderate growth of ${changePercent.toFixed(1)}% in sales. `;
    } else {
      message += `📉 Sales declined by ${Math.abs(changePercent).toFixed(1)}%. `;
    }
    
    message += `Units sold changed by ${unitsChange} units.\n\n`;
    message += `Key Recommendations:\n`;
    message += `• Focus on high-visibility placement for underperforming items\n`;
    message += `• Monitor stock levels for bestselling products\n`;
    message += `• Consider seasonal promotions to boost traffic`;
    
    // Generate actionable recommendations
    const actions = [];
    
    // Analyze SKUs to create relevant actions
    if (skuList && skuList.length > 0) {
      // Action 1: Move slow movers
      actions.push({
        title: 'Move slow-moving items to the front of store',
        description: 'Items with declining sales should be relocated to high-visibility areas near the entrance to increase customer exposure and boost sales.',
        action: 'move_item_to_front',
        sku_id: skuList[0]?.sku_id || 'SKU001'
      });
      
      // Action 2: Restock bestsellers
      actions.push({
        title: 'Restock bestselling items',
        description: 'Popular items may be running low on inventory. Ensure adequate stock levels are maintained to meet customer demand and prevent lost sales.',
        action: 'restock_item',
        sku_id: skuList[Math.min(1, skuList.length - 1)]?.sku_id || 'SKU002'
      });
      
      // Action 3: Create promotional display
      actions.push({
        title: 'Create promotional display for seasonal items',
        description: 'Highlight trending or seasonal merchandise with eye-catching displays at strategic locations to drive impulse purchases and increase average transaction value.',
        action: 'highlight_item',
        sku_id: skuList[Math.min(2, skuList.length - 1)]?.sku_id || 'SKU003'
      });
    }
    
    return {
      message,
      actions
    };
  };

  const handleCompare = () => {
    loadComparison(week1, week2);
  };

  const handleSKUSelect = async (e) => {
    const sku = e.target.value;
    setSelectedSKU(sku);
    
    if (sku) {
      try {
        const trend = await api.getSKUTrend(sku, 5);
        setSkuTrend(trend);
      } catch (err) {
        console.error('Error loading SKU trend:', err);
      }
    } else {
      setSkuTrend(null);
    }
  };

  const handleSeeInStore = async (action) => {
    // This function will interact with the 3D scene image
    // For now, it will log the action and show an alert
    console.log('Applying action to store:', action);
    alert(`Action: ${action}\n\nThis will update the 3D store view. (Feature coming soon)`);
    
    // TODO: Implement actual 3D scene manipulation
    // This would involve:
    // 1. Calling an API endpoint to modify the store layout
    // 2. Updating the DisplayImageEditor with the new arrangement
    // 3. Possibly using image editing to highlight the changes
  };

  // Prepare chart data for all SKUs
  const getChartDataForAllSKUs = () => {
    if (allSKUsTrends.length === 0) return [];
    
    // Get all unique weeks
    const weeks = [...new Set(allSKUsTrends.flatMap(t => t.weeks.map(w => w.week)))].sort();
    
    // Create chart data with all SKUs
    return weeks.map(week => {
      const dataPoint = { week: `Week ${week}` };
      allSKUsTrends.forEach(trend => {
        const weekData = trend.weeks.find(w => w.week === week);
        dataPoint[trend.sku_id] = weekData ? weekData.units_sold : 0;
      });
      return dataPoint;
    });
  };

  const chartData = getChartDataForAllSKUs();
  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', '#d084d0', '#a4de6c'];

  if (loading && !comparison) {
    return <div style={styles.loading}>Loading analytics...</div>;
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={styles.title}>Analytics Dashboard</h2>
        <div style={styles.weekBadge}>
          Current Week: {currentWeek}
        </div>
      </div>

      {/* Week Comparison Selector */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Compare Weeks</h3>
        <div style={styles.comparisonControls}>
          <div>
            <label style={styles.label}>Week 1:</label>
            <select value={week1} onChange={(e) => setWeek1(parseInt(e.target.value))} style={styles.select}>
              {[...Array(currentWeek)].map((_, i) => (
                <option key={i + 1} value={i + 1}>Week {i + 1}</option>
              ))}
            </select>
          </div>
          <div>
            <label style={styles.label}>Week 2:</label>
            <select value={week2} onChange={(e) => setWeek2(parseInt(e.target.value))} style={styles.select}>
              {[...Array(currentWeek)].map((_, i) => (
                <option key={i + 1} value={i + 1}>Week {i + 1}</option>
              ))}
            </select>
          </div>
          <button onClick={handleCompare} style={styles.compareButton}>
            Compare
          </button>
        </div>
      </div>

      {/* Comparison Results */}
      {comparison && (
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Week {week1} vs Week {week2}</h3>
          <div style={styles.metricsGrid}>
            <div style={styles.metricCard}>
              <div style={styles.metricLabel}>Total Sales</div>
              <div style={styles.metricValue}>
                ${comparison.week2.total_sales.toFixed(2)}
              </div>
              <div style={{
                ...styles.metricChange,
                color: comparison.change.sales_change >= 0 ? '#38a169' : '#e53e3e'
              }}>
                {comparison.change.sales_change >= 0 ? '↑' : '↓'} 
                {Math.abs(comparison.change.sales_change_pct).toFixed(1)}%
                (${Math.abs(comparison.change.sales_change).toFixed(2)})
              </div>
            </div>

            <div style={styles.metricCard}>
              <div style={styles.metricLabel}>Units Sold</div>
              <div style={styles.metricValue}>
                {comparison.week2.total_units}
              </div>
              <div style={{
                ...styles.metricChange,
                color: comparison.change.units_change >= 0 ? '#38a169' : '#e53e3e'
              }}>
                {comparison.change.units_change >= 0 ? '↑' : '↓'} 
                {Math.abs(comparison.change.units_change_pct).toFixed(1)}%
                ({Math.abs(comparison.change.units_change)} units)
              </div>
            </div>

            <div style={styles.metricCard}>
              <div style={styles.metricLabel}>Transactions</div>
              <div style={styles.metricValue}>
                {comparison.week2.num_transactions}
              </div>
              <div style={styles.metricChange}>
                Week {week1}: {comparison.week1.num_transactions}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Units Sold Chart for All Items */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Units Sold Trends - All Items</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="week" />
            <YAxis />
            <Tooltip />
            <Legend />
            {allSKUsTrends.map((trend, idx) => (
              <Line 
                key={trend.sku_id}
                type="monotone" 
                dataKey={trend.sku_id}
                stroke={colors[idx % colors.length]}
                name={`${trend.sku_id} - ${trend.product_name}`}
                strokeWidth={2}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* AI Insights with Action Buttons */}
      {aiInsights && (
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>🤖 AI-Powered Insights & Recommendations</h3>
          <div style={styles.insightsBox}>
            {aiInsights.message}
          </div>
          
          {aiInsights.actions && aiInsights.actions.length > 0 && (
            <div style={styles.actionsContainer}>
              <h4 style={styles.actionsTitle}>Recommended Actions:</h4>
              {aiInsights.actions.map((action, idx) => (
                <div key={idx} style={styles.actionItem}>
                  <div style={styles.actionText}>
                    <strong>{action.title}</strong>
                    <p style={styles.actionDescription}>{action.description}</p>
                  </div>
                  <button 
                    style={styles.seeInStoreButton}
                    onClick={() => handleSeeInStore(action.action)}
                  >
                    See in Store
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SKU Detail Trend Analysis */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>Individual SKU Analysis</h3>
        <select value={selectedSKU} onChange={handleSKUSelect} style={styles.select}>
          <option value="">Select a SKU...</option>
          {skus.map(sku => (
            <option key={sku.sku_id} value={sku.sku_id}>
              {sku.sku_id} - {sku.product_name}
            </option>
          ))}
        </select>

        {skuTrend && (
          <div style={styles.trendContainer}>
            <div style={styles.trendBadge}>
              Trend: <strong>{skuTrend.trend.toUpperCase()}</strong>
            </div>
            
            {/* SKU-specific chart */}
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={skuTrend.weeks.map(w => ({ week: `Week ${w.week}`, units: w.units_sold }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="units" stroke="#8884d8" name="Units Sold" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>

            <table style={styles.table}>
              <thead>
                <tr style={styles.tableHeader}>
                  <th style={styles.th}>Week</th>
                  <th style={styles.th}>Units Sold</th>
                  <th style={styles.th}>Revenue</th>
                  <th style={styles.th}>Transactions</th>
                </tr>
              </thead>
              <tbody>
                {skuTrend.weeks.map((week, idx) => (
                  <tr key={week.week} style={idx % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd}>
                    <td style={styles.td}>Week {week.week}</td>
                    <td style={styles.td}>{week.units_sold}</td>
                    <td style={styles.td}>${week.revenue.toFixed(2)}</td>
                    <td style={styles.td}>{week.transactions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1400px',
    margin: '0 auto',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '30px',
    flexWrap: 'wrap',
    gap: '15px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#2d3748',
  },
  weekBadge: {
    padding: '10px 20px',
    backgroundColor: '#4299e1',
    color: '#fff',
    borderRadius: '20px',
    fontWeight: '600',
    fontSize: '16px',
  },
  loading: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#718096',
  },
  section: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    marginBottom: '20px',
  },
  sectionTitle: {
    fontSize: '20px',
    fontWeight: '600',
    marginBottom: '20px',
    color: '#2d3748',
  },
  comparisonControls: {
    display: 'flex',
    gap: '20px',
    alignItems: 'flex-end',
    flexWrap: 'wrap',
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: '600',
    color: '#4a5568',
    marginBottom: '8px',
  },
  select: {
    padding: '10px 12px',
    fontSize: '14px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    minWidth: '150px',
  },
  compareButton: {
    padding: '10px 24px',
    backgroundColor: '#4299e1',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
  },
  metricsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '20px',
  },
  metricCard: {
    padding: '20px',
    backgroundColor: '#f7fafc',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  metricLabel: {
    fontSize: '14px',
    color: '#718096',
    marginBottom: '8px',
  },
  metricValue: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#2d3748',
    marginBottom: '8px',
  },
  metricChange: {
    fontSize: '14px',
    fontWeight: '600',
  },
  insightsBox: {
    padding: '20px',
    backgroundColor: '#ebf8ff',
    borderRadius: '8px',
    border: '1px solid #90cdf4',
    lineHeight: '1.6',
    color: '#2c5282',
    whiteSpace: 'pre-wrap',
  },
  actionsContainer: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: '#f7fafc',
    borderRadius: '8px',
  },
  actionsTitle: {
    fontSize: '16px',
    fontWeight: '600',
    marginBottom: '15px',
    color: '#2d3748',
  },
  actionItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '15px',
    marginBottom: '10px',
    backgroundColor: '#fff',
    borderRadius: '6px',
    border: '1px solid #e2e8f0',
    gap: '15px',
  },
  actionText: {
    flex: 1,
  },
  actionDescription: {
    margin: '5px 0 0 0',
    fontSize: '14px',
    color: '#718096',
  },
  seeInStoreButton: {
    padding: '10px 20px',
    backgroundColor: '#48bb78',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
    transition: 'background-color 0.2s',
  },
  trendContainer: {
    marginTop: '20px',
  },
  trendBadge: {
    display: 'inline-block',
    padding: '8px 16px',
    backgroundColor: '#edf2f7',
    borderRadius: '6px',
    marginBottom: '15px',
    fontSize: '14px',
    color: '#2d3748',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
  },
  tableHeader: {
    backgroundColor: '#edf2f7',
  },
  th: {
    padding: '12px',
    textAlign: 'left',
    fontWeight: '600',
    color: '#4a5568',
    borderBottom: '2px solid #cbd5e0',
  },
  td: {
    padding: '12px',
    borderBottom: '1px solid #e2e8f0',
    color: '#2d3748',
  },
  tableRowEven: {
    backgroundColor: '#fff',
  },
  tableRowOdd: {
    backgroundColor: '#f7fafc',
  },
};

export default Analytics;
