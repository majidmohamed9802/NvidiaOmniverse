import React, { useState, useEffect } from 'react';
import api from '../services/api';

function DailyPlan() {
  const [zone, setZone] = useState('Central Mannequin');
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [displayImage, setDisplayImage] = useState(null);
  const [hasDisplaySession, setHasDisplaySession] = useState(false);

  const zones = [
    'Central Mannequin',
    'Focus Table',
    'Accessories Corner'
  ];

  useEffect(() => {
    checkDisplaySession();
  }, [zone]);

  const checkDisplaySession = async () => {
    try {
      const session = await api.getDisplaySession(zone);
      if (session.success && session.current_image) {
        setDisplayImage(session.current_image);
        setHasDisplaySession(true);
      }
    } catch (err) {
      setHasDisplaySession(false);
    }
  };

  const generatePlan = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Generate the plan with structured output
      const response = await api.generateStructuredPlan(zone, displayImage);
      setPlan(response);
    } catch (err) {
      setError('Failed to generate plan');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const downloadPDF = () => {
    // TODO: Implement PDF generation
    alert('PDF download coming soon!');
  };

  const sendToTeam = () => {
    // TODO: Implement email/share functionality
    alert('Share to team coming soon!');
  };

  if (loading) {
    return (
      <div style={styles.loading}>
        <div style={styles.loadingSpinner}></div>
        <p>Generating your daily plan...</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1 style={styles.title}>Daily Visual Merchandising Plan</h1>
        <p style={styles.subtitle}>Generate execution-ready display plans for your store</p>
      </header>

      {/* Zone Selection */}
      <div style={styles.controlSection}>
        <label style={styles.label}>Select Display Zone:</label>
        <div style={styles.zoneButtons}>
          {zones.map(z => (
            <button
              key={z}
              onClick={() => setZone(z)}
              style={{
                ...styles.zoneButton,
                ...(zone === z ? styles.zoneButtonActive : {})
              }}
            >
              {z}
            </button>
          ))}
        </div>

        {hasDisplaySession && (
          <div style={styles.imageInfo}>
            ✓ Display image available from Display Editor
          </div>
        )}

        <button onClick={generatePlan} disabled={loading} style={styles.generateButton}>
          Generate Daily Plan →
        </button>
      </div>

      {error && (
        <div style={styles.error}>{error}</div>
      )}

      {/* Professional Plan Output */}
      {plan && (
        <div style={styles.planDocument}>
          {/* Header with Image */}
          <div style={styles.planHeader}>
            <h2 style={styles.planTitle}>New Visual: {zone}</h2>
          </div>

          {/* Display Image */}
          {plan.visual_image && (
            <div style={styles.visualSection}>
              <img src={plan.visual_image} alt="Display" style={styles.displayImage} />
            </div>
          )}

          {/* Product Playground */}
          {plan.products && plan.products.length > 0 && (
            <div style={styles.section}>
              <h3 style={styles.sectionTitle}>Product Playground</h3>
              <div style={styles.productGrid}>
                {plan.products.map((product, idx) => (
                  <div key={idx} style={styles.productCard}>
                    <div style={styles.productName}>{product.name}</div>
                    <div style={styles.productSku}>{product.sku_id}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Visual Prompt */}
          {plan.visual_prompt && (
            <div style={styles.section}>
              <h3 style={styles.sectionTitle}>Visual Prompt</h3>
              <p style={styles.promptText}>{plan.visual_prompt}</p>
            </div>
          )}

          {/* Execution Brief */}
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Execution Brief</h3>
            <ol style={styles.executionList}>
              {plan.execution_steps && plan.execution_steps.map((step, idx) => (
                <li key={idx} style={styles.executionStep}>{step}</li>
              ))}
            </ol>
          </div>

          {/* Staff Talking Points */}
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Staff Talking Points</h3>
            
            {plan.talking_points && (
              <div style={styles.talkingPoints}>
                {plan.talking_points.whats_new && (
                  <div style={styles.talkingPoint}>
                    <strong>What's New:</strong>
                    <p>{plan.talking_points.whats_new}</p>
                  </div>
                )}
                
                {plan.talking_points.coordinate_choice && (
                  <div style={styles.talkingPoint}>
                    <strong>Coordinate Choice:</strong>
                    <p>{plan.talking_points.coordinate_choice}</p>
                  </div>
                )}
                
                {plan.talking_points.slow_movers && (
                  <div style={styles.talkingPoint}>
                    <strong>Slow Movers Selling Points:</strong>
                    <p>{plan.talking_points.slow_movers}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Refine Plan Section */}
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Refine Plan</h3>
            <p style={styles.refineText}>Not quite right? Add a note below and regenerate the plan</p>
            <textarea 
              style={styles.refineInput}
              placeholder="Change! Add more blue items, remove the scarf..."
            />
          </div>

          {/* Action Buttons */}
          <div style={styles.actionButtons}>
            <button onClick={downloadPDF} style={{...styles.actionButton, ...styles.downloadButton}}>
              Download as PDF
            </button>
            <button onClick={sendToTeam} style={{...styles.actionButton, ...styles.shareButton}}>
              Send to Store Team
            </button>
            <button onClick={generatePlan} style={{...styles.actionButton, ...styles.regenerateButton}}>
              Regenerate Plan
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1000px',
    margin: '0 auto',
    backgroundColor: '#f7fafc',
  },
  header: {
    marginBottom: '30px',
  },
  title: {
    fontSize: '32px',
    fontWeight: 'bold',
    color: '#2d3748',
    marginBottom: '8px',
  },
  subtitle: {
    fontSize: '16px',
    color: '#718096',
  },
  controlSection: {
    backgroundColor: '#fff',
    padding: '25px',
    borderRadius: '8px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    marginBottom: '25px',
  },
  label: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#4a5568',
    marginBottom: '12px',
    display: 'block',
  },
  zoneButtons: {
    display: 'flex',
    gap: '10px',
    marginBottom: '20px',
    flexWrap: 'wrap',
  },
  zoneButton: {
    padding: '12px 24px',
    border: '2px solid #e2e8f0',
    borderRadius: '6px',
    backgroundColor: '#fff',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    color: '#4a5568',
    transition: 'all 0.2s',
  },
  zoneButtonActive: {
    borderColor: '#4299e1',
    backgroundColor: '#ebf8ff',
    color: '#2c5282',
  },
  imageInfo: {
    padding: '10px 15px',
    backgroundColor: '#c6f6d5',
    borderRadius: '6px',
    fontSize: '14px',
    color: '#22543d',
    marginBottom: '15px',
  },
  generateButton: {
    width: '100%',
    padding: '14px',
    backgroundColor: '#4299e1',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  loading: {
    textAlign: 'center',
    padding: '60px 20px',
  },
  loadingSpinner: {
    width: '50px',
    height: '50px',
    border: '4px solid #e2e8f0',
    borderTop: '4px solid #4299e1',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
    margin: '0 auto 20px',
  },
  error: {
    padding: '15px',
    backgroundColor: '#fed7d7',
    border: '1px solid #fc8181',
    borderRadius: '6px',
    color: '#742a2a',
    marginBottom: '20px',
  },
  planDocument: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    overflow: 'hidden',
  },
  planHeader: {
    padding: '25px',
    backgroundColor: '#2d3748',
    color: '#fff',
  },
  planTitle: {
    fontSize: '24px',
    fontWeight: 'bold',
    margin: 0,
  },
  visualSection: {
    padding: '0',
    backgroundColor: '#000',
  },
  displayImage: {
    width: '100%',
    height: 'auto',
    display: 'block',
  },
  section: {
    padding: '25px',
    borderBottom: '1px solid #e2e8f0',
  },
  sectionTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: '15px',
  },
  productGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
    gap: '12px',
  },
  productCard: {
    padding: '15px',
    backgroundColor: '#edf2f7',
    borderRadius: '6px',
    textAlign: 'center',
  },
  productName: {
    fontSize: '13px',
    fontWeight: '500',
    color: '#2d3748',
    marginBottom: '4px',
  },
  productSku: {
    fontSize: '12px',
    color: '#718096',
    fontFamily: 'monospace',
  },
  promptText: {
    fontSize: '14px',
    lineHeight: '1.6',
    color: '#4a5568',
    fontStyle: 'italic',
  },
  executionList: {
    paddingLeft: '20px',
    margin: 0,
  },
  executionStep: {
    fontSize: '14px',
    lineHeight: '1.8',
    color: '#2d3748',
    marginBottom: '8px',
  },
  talkingPoints: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  talkingPoint: {
    fontSize: '14px',
    lineHeight: '1.6',
    color: '#2d3748',
  },
  refineText: {
    fontSize: '14px',
    color: '#718096',
    marginBottom: '12px',
  },
  refineInput: {
    width: '100%',
    minHeight: '80px',
    padding: '12px',
    border: '1px solid #cbd5e0',
    borderRadius: '6px',
    fontSize: '14px',
    fontFamily: 'inherit',
    resize: 'vertical',
  },
  actionButtons: {
    display: 'flex',
    gap: '12px',
    padding: '25px',
    backgroundColor: '#f7fafc',
    flexWrap: 'wrap',
  },
  actionButton: {
    flex: 1,
    minWidth: '180px',
    padding: '12px 20px',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  downloadButton: {
    backgroundColor: '#2d3748',
    color: '#fff',
  },
  shareButton: {
    backgroundColor: '#48bb78',
    color: '#fff',
  },
  regenerateButton: {
    backgroundColor: '#4299e1',
    color: '#fff',
  },
};

export default DailyPlan;
