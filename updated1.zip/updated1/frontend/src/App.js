import React, { useState, useEffect } from 'react';
import DailyPlan from './components/DailyPlan';
import DisplayImageEditor from './components/DisplayImageEditor';
import AddSKU from './components/AddSKU';
import Analytics from './components/Analytics';
import api from './services/api';

function App() {
  const [activeTab, setActiveTab] = useState('analytics');
  const [aiEnabled, setAiEnabled] = useState(false);

  useEffect(() => {
    checkHealth();
  }, []);

  const checkHealth = async () => {
    try {
      const health = await api.healthCheck();
      setAiEnabled(health.ai_enabled);
    } catch (error) {
      console.error('Health check failed:', error);
    }
  };

  const tabs = [
    { id: 'analytics', label: 'Analytics' },
    { id: 'add-sku', label: 'Add SKU' },
    { id: '3d-viewer', label: '3D Store Viewer' },
    { id: 'image-editor', label: 'Display Editor' },
  ];

  return (
    <div style={styles.app}>
      <header style={styles.header}>
        <div style={styles.headerContent}>
          <h1 style={styles.title}>AI Visual Merchandiser</h1>
          <div style={styles.statusBadge}>
            <span style={{ ...styles.statusDot, backgroundColor: aiEnabled ? '#48bb78' : '#f56565' }}></span>
            {aiEnabled ? 'AI Active' : 'Data Only'}
          </div>
        </div>
      </header>

      {!aiEnabled && (
        <div style={styles.warningBanner}>
          <strong>WARNING: AI Features Disabled</strong> - Configure GCP credentials to enable AI-powered features.
          Currently running in data visualization mode only.
        </div>
      )}

      <nav style={styles.nav}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            style={{
              ...styles.navButton,
              ...(activeTab === tab.id ? styles.navButtonActive : {}),
            }}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      <main style={styles.main}>
        {activeTab === 'analytics' && <Analytics />}
        {activeTab === 'add-sku' && <AddSKU />}
        {activeTab === '3d-viewer' && <DailyPlan />}
        {activeTab === 'image-editor' && <DisplayImageEditor />}
      </main>
    </div>
  );
}

const styles = {
  app: {
    minHeight: '100vh',
    backgroundColor: '#f7fafc',
  },
  header: {
    backgroundColor: '#fff',
    borderBottom: '1px solid #e2e8f0',
    padding: '0 20px',
  },
  headerContent: {
    maxWidth: '1400px',
    margin: '0 auto',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px 0',
  },
  title: {
    fontSize: '24px',
    fontWeight: 'bold',
    margin: 0,
    display: 'flex',
    alignItems: 'center',
  },
  statusBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 16px',
    backgroundColor: '#edf2f7',
    borderRadius: '20px',
    fontSize: '14px',
    fontWeight: '500',
  },
  statusDot: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
  },
  warningBanner: {
    backgroundColor: '#fff5f5',
    borderLeft: '4px solid #fc8181',
    padding: '16px 20px',
    color: '#742a2a',
  },
  nav: {
    backgroundColor: '#fff',
    borderBottom: '1px solid #e2e8f0',
    display: 'flex',
    padding: '0 20px',
    maxWidth: '1400px',
    margin: '0 auto',
  },
  navButton: {
    padding: '16px 24px',
    backgroundColor: 'transparent',
    border: 'none',
    borderBottom: '3px solid transparent',
    cursor: 'pointer',
    fontSize: '15px',
    fontWeight: '500',
    color: '#718096',
    display: 'flex',
    alignItems: 'center',
    transition: 'all 0.2s',
  },
  navButtonActive: {
    color: '#2d3748',
    borderBottomColor: '#4299e1',
  },
  main: {
    maxWidth: '1400px',
    margin: '0 auto',
    padding: '20px',
  },
};

export default App;
