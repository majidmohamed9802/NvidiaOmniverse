const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

class ApiService {
  async request(endpoint, options = {}) {
    const config = {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    };

    const response = await fetch(`${API_URL}${endpoint}`, config);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Request failed');
    }
    
    return response.json();
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }

  // Analytics
  async getZonePerformance(days = 30) {
    return this.request(`/api/analytics/zones?days=${days}`);
  }

  async getTopPerformers(limit = 10, days = 30) {
    return this.request(`/api/analytics/top-performers?days=${days}&limit=${limit}`);
  }

  // FIXED: Added missing getSlowMovers method
  async getSlowMovers() {
    return this.request('/api/analytics/slow-movers');
  }

  // Week Management
  async getCurrentWeek() {
    return this.request('/api/weeks/current');
  }

  async advanceWeek() {
    return this.request('/api/weeks/advance', { method: 'POST' });
  }

  async compareWeeks(week1, week2) {
    return this.request(`/api/weeks/compare?week1=${week1}&week2=${week2}`);
  }

  async getWeeklySales(week = null) {
    const url = week ? `/api/weeks/sales?week=${week}` : '/api/weeks/sales';
    return this.request(url);
  }

  async getSKUTrend(skuId, weeks = 5) {
    return this.request(`/api/skus/${skuId}/trend?weeks=${weeks}`);
  }

  // SKU Management
  async getSKUs() {
    return this.request('/api/skus');
  }

  async addSKU(skuData) {
    return this.request('/api/skus', {
      method: 'POST',
      body: JSON.stringify(skuData),
    });
  }

  // AI Insights for weekly comparison
  async getWeeklyInsights(comparisonData) {
    // This would call the AI agent to analyze the comparison
    const prompt = `Analyze this week-over-week performance data and provide insights:
    
Week ${comparisonData.week1.week}: $${comparisonData.week1.total_sales.toFixed(2)} sales, ${comparisonData.week1.total_units} units
Week ${comparisonData.week2.week}: $${comparisonData.week2.total_sales.toFixed(2)} sales, ${comparisonData.week2.total_units} units

Change: ${comparisonData.change.sales_change_pct.toFixed(1)}% in sales, ${comparisonData.change.units_change_pct.toFixed(1)}% in units

Provide:
1. Performance assessment
2. Possible reasons for the change
3. Actionable recommendations`;

    return this.request('/api/display/create', {
      method: 'POST',
      body: JSON.stringify({ 
        prompt: prompt,
        zone: 'Analytics'
      }),
    });
  }

  // Enhanced AI Insights with actionable recommendations
  async getEnhancedWeeklyInsights(comparisonData, skus) {
    const prompt = `You are analyzing retail store performance data. Based on the following week-over-week comparison and SKU data, provide insights and specific actionable recommendations.

Week-over-Week Performance:
- Week ${comparisonData.week1.week}: $${comparisonData.week1.total_sales.toFixed(2)} sales, ${comparisonData.week1.total_units} units
- Week ${comparisonData.week2.week}: $${comparisonData.week2.total_sales.toFixed(2)} sales, ${comparisonData.week2.total_units} units
- Change: ${comparisonData.change.sales_change_pct.toFixed(1)}% in sales, ${comparisonData.change.units_change_pct.toFixed(1)}% in units

Available SKUs:
${skus.map(s => `- ${s.sku_id}: ${s.product_name} ($${s.price})`).join('\n')}

Provide:
1. A clear performance assessment
2. Specific recommendations for improving sales

Format your response as JSON with this structure:
{
  "message": "Your detailed analysis text here",
  "actions": [
    {
      "title": "Action title",
      "description": "What to do and why",
      "action": "move_item_to_front|restock_item|highlight_item",
      "sku_id": "relevant SKU if applicable"
    }
  ]
}

Focus on identifying:
- Slow-moving items that should be moved to high-visibility areas
- Best sellers that need restocking
- Items that could benefit from better placement or promotion`;

    return this.request('/api/analytics/enhanced-insights', {
      method: 'POST',
      body: JSON.stringify({ 
        prompt: prompt,
        comparison_data: comparisonData,
        skus: skus
      }),
    });
  }

  // Daily Plan
  async generateDailyPlan(zone) {
    return this.request('/api/daily-plan', {
      method: 'POST',
      body: JSON.stringify({ zone }),
    });
  }

  // Display Creation - FIXED: parameter order matches backend expectation
  async createDisplay(prompt, zone) {
    return this.request('/api/display/create', {
      method: 'POST',
      body: JSON.stringify({ prompt, zone }),
    });
  }

  // Display Image Editor
  async uploadBaseImage(zone, imageBase64, userId = 'default') {
    return this.request('/api/display-editor/upload-base', {
      method: 'POST',
      body: JSON.stringify({ zone, image: imageBase64, user_id: userId }),
    });
  }

  async editDisplayImage(zone, command, userId = 'default') {
    return this.request('/api/display-editor/edit', {
      method: 'POST',
      body: JSON.stringify({ zone, command, user_id: userId }),
    });
  }

  async resetDisplayImage(zone, userId = 'default') {
    return this.request('/api/display-editor/reset', {
      method: 'POST',
      body: JSON.stringify({ zone, user_id: userId }),
    });
  }

  async getDisplaySession(zone, userId = 'default') {
    return this.request(`/api/display-editor/session?zone=${encodeURIComponent(zone)}&user_id=${userId}`);
  }
}

export default new ApiService();
