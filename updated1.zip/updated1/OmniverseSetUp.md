# NVIDIA Omniverse 3D Store Viewer Integration Guide

## 🎯 Overview

This guide is for the developer integrating NVIDIA Omniverse 3D visualization into the AI Visual Merchandiser application. A placeholder component has been created in the **3D Store Viewer** tab specifically for your Omniverse integration.

---

## 📍 Current State

### Placeholder Component Location

**File:** `frontend/src/components/ThreeDViewer.js`

This is currently a basic Three.js placeholder that you'll replace with your NVIDIA Omniverse component.

### Where It's Used

1. **DailyPlan.js** (3D Store Viewer tab)
   ```javascript
   import ThreeDViewer from './ThreeDViewer';
   
   <ThreeDViewer displayData={plan} />
   ```

2. **Future: Analytics "See in Store" Integration**
   - When users click "See in Store" buttons
   - Should navigate to your 3D viewer
   - Highlights specific items that need attention

---

## 🔌 Integration Points

### Props Your Component Will Receive

```javascript
function YourOmniverseComponent({ 
  displayData,        // Store layout and item data from AI
  highlightItems,     // Array of SKU IDs to highlight ["SKU001", "SKU003"]
  pendingChanges      // Array of recommended changes to visualize
}) {
  // Your Omniverse implementation
}
```

### Data Structure Examples

#### displayData
```json
{
  "zone": "Front Window",
  "items": [
    {
      "sku_id": "SKU001",
      "product_name": "Premium Jacket",
      "price": 89.99,
      "quantity": 5,
      "position": { "x": 0, "y": 0, "z": 0 }
    },
    {
      "sku_id": "SKU002",
      "product_name": "Designer Scarf",
      "price": 45.00,
      "quantity": 12,
      "position": { "x": 2, "y": 0, "z": 1 }
    }
  ],
  "message": "AI-generated merchandising strategy and placement guidance"
}
```

#### highlightItems
```javascript
["SKU001", "SKU003"]
// These items should be visually highlighted in the 3D scene
// (coming from "See in Store" button clicks)
```

#### pendingChanges
```javascript
[
  {
    "type": "move",
    "sku_id": "SKU001",
    "from": { "x": 5, "y": 0, "z": 2 },
    "to": { "x": 0, "y": 0, "z": 0 },
    "reason": "Move to front of store for better visibility",
    "action": "move_item_to_front"
  },
  {
    "type": "restock",
    "sku_id": "SKU002",
    "reason": "Bestseller running low on stock",
    "action": "restock_item"
  },
  {
    "type": "highlight",
    "sku_id": "SKU003",
    "reason": "Create promotional display",
    "action": "highlight_item"
  }
]
```

---

## 🚀 Implementation Options

### Option 1: Omniverse Kit Embedded (Recommended)

Best for: Full control, complex scenes, real-time updates

#### Installation

```bash
cd frontend
npm install @nvidia/omniverse-client
# Or your specific SDK package
```

#### Component Template

```javascript
// frontend/src/components/NvidiaOmniverseViewer.js
import React, { useEffect, useRef, useState } from 'react';
import { OmniverseKit } from '@nvidia/omniverse-client';

function NvidiaOmniverseViewer({ 
  displayData, 
  highlightItems = [], 
  pendingChanges = [] 
}) {
  const containerRef = useRef(null);
  const omniverseRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Initialize Omniverse
  useEffect(() => {
    if (!containerRef.current) return;

    const initOmniverse = async () => {
      try {
        omniverseRef.current = new OmniverseKit({
          container: containerRef.current,
          serverUrl: process.env.REACT_APP_OMNIVERSE_SERVER_URL,
          width: containerRef.current.clientWidth,
          height: 600,
        });

        await omniverseRef.current.connect();
        
        // Load base store scene
        await omniverseRef.current.loadScene(
          'omniverse://localhost/retail_store/main_store.usd'
        );
        
        setIsLoading(false);
      } catch (err) {
        console.error('Omniverse initialization failed:', err);
        setError(err.message);
        setIsLoading(false);
      }
    };

    initOmniverse();

    // Cleanup
    return () => {
      if (omniverseRef.current) {
        omniverseRef.current.disconnect();
      }
    };
  }, []);

  // Update store layout when displayData changes
  useEffect(() => {
    if (!omniverseRef.current || !displayData || isLoading) return;

    const updateStoreLayout = async () => {
      try {
        // Update items in the scene
        if (displayData.items) {
          for (const item of displayData.items) {
            await omniverseRef.current.updatePrim(
              `/World/Store/Items/${item.sku_id}`, 
              {
                position: [
                  item.position.x, 
                  item.position.y, 
                  item.position.z
                ],
                attributes: {
                  quantity: item.quantity,
                  product_name: item.product_name
                }
              }
            );
          }
        }
      } catch (err) {
        console.error('Failed to update store layout:', err);
      }
    };

    updateStoreLayout();
  }, [displayData, isLoading]);

  // Highlight items when highlightItems changes
  useEffect(() => {
    if (!omniverseRef.current || highlightItems.length === 0 || isLoading) return;

    const applyHighlights = async () => {
      try {
        // Clear previous highlights
        await omniverseRef.current.clearHighlights();

        // Apply new highlights
        for (const skuId of highlightItems) {
          await omniverseRef.current.highlightPrim(
            `/World/Store/Items/${skuId}`,
            {
              color: [1.0, 0.84, 0.0],  // Gold color
              intensity: 2.0,
              pulse: true,
              pulseSpeed: 1.5
            }
          );
        }

        // Focus camera on highlighted items
        if (highlightItems.length === 1) {
          await omniverseRef.current.focusCamera(
            `/World/Store/Items/${highlightItems[0]}`
          );
        }
      } catch (err) {
        console.error('Failed to apply highlights:', err);
      }
    };

    applyHighlights();
  }, [highlightItems, isLoading]);

  // Visualize pending changes
  useEffect(() => {
    if (!omniverseRef.current || pendingChanges.length === 0 || isLoading) return;

    const visualizeChanges = async () => {
      try {
        for (const change of pendingChanges) {
          if (change.type === 'move') {
            // Show movement arrow
            await omniverseRef.current.createArrow({
              from: [change.from.x, change.from.y, change.from.z],
              to: [change.to.x, change.to.y, change.to.z],
              color: [0.0, 1.0, 0.0],  // Green
              label: change.reason
            });
          } else if (change.type === 'highlight' || change.type === 'restock') {
            // Add floating label
            await omniverseRef.current.createLabel({
              position: `/World/Store/Items/${change.sku_id}`,
              text: change.reason,
              color: [1.0, 1.0, 1.0]
            });
          }
        }
      } catch (err) {
        console.error('Failed to visualize changes:', err);
      }
    };

    visualizeChanges();
  }, [pendingChanges, isLoading]);

  if (error) {
    return (
      <div style={styles.errorContainer}>
        <h3>Failed to load Omniverse Scene</h3>
        <p>{error}</p>
        <p>Please check your Omniverse server connection and try again.</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {isLoading && (
        <div style={styles.loadingOverlay}>
          <div style={styles.loadingSpinner}></div>
          <p>Loading NVIDIA Omniverse Scene...</p>
        </div>
      )}
      <div ref={containerRef} style={styles.viewport} />
    </div>
  );
}

const styles = {
  container: {
    width: '100%',
    height: '600px',
    position: 'relative',
    backgroundColor: '#1a1a1a',
    borderRadius: '8px',
    overflow: 'hidden'
  },
  viewport: {
    width: '100%',
    height: '100%'
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    color: '#fff',
    zIndex: 10
  },
  loadingSpinner: {
    width: '50px',
    height: '50px',
    border: '4px solid rgba(255, 255, 255, 0.3)',
    borderTop: '4px solid #76b900',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
    marginBottom: '20px'
  },
  errorContainer: {
    width: '100%',
    height: '600px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffe0e0',
    color: '#c00',
    padding: '40px',
    borderRadius: '8px'
  }
};

export default NvidiaOmniverseViewer;
```

### Option 2: CloudXR Streaming

Best for: Remote rendering, high-quality graphics, lower client requirements

#### Installation

```bash
npm install @nvidia/cloudxr
```

#### Component Template

```javascript
// frontend/src/components/NvidiaCloudXRViewer.js
import React, { useEffect, useRef, useState } from 'react';
import { CloudXRClient } from '@nvidia/cloudxr';

function NvidiaCloudXRViewer({ displayData, highlightItems, pendingChanges }) {
  const containerRef = useRef(null);
  const clientRef = useRef(null);
  const [status, setStatus] = useState('Connecting...');

  useEffect(() => {
    const initCloudXR = async () => {
      try {
        clientRef.current = new CloudXRClient({
          container: containerRef.current,
          serverAddress: process.env.REACT_APP_CLOUDXR_SERVER,
          serverPort: 48010,
          autoConnect: true,
          streamWidth: 1920,
          streamHeight: 1080
        });

        clientRef.current.on('connected', () => {
          setStatus('Connected');
        });

        clientRef.current.on('disconnected', () => {
          setStatus('Disconnected');
        });

        clientRef.current.on('error', (error) => {
          setStatus(`Error: ${error.message}`);
        });

        await clientRef.current.connect();
      } catch (error) {
        setStatus(`Connection failed: ${error.message}`);
      }
    };

    initCloudXR();

    return () => {
      if (clientRef.current) {
        clientRef.current.disconnect();
      }
    };
  }, []);

  // Send store data to CloudXR server
  useEffect(() => {
    if (!clientRef.current || !displayData) return;

    clientRef.current.sendMessage({
      type: 'UPDATE_STORE_LAYOUT',
      data: displayData
    });
  }, [displayData]);

  // Send highlight commands
  useEffect(() => {
    if (!clientRef.current || highlightItems.length === 0) return;

    clientRef.current.sendMessage({
      type: 'HIGHLIGHT_ITEMS',
      items: highlightItems
    });
  }, [highlightItems]);

  // Send pending changes
  useEffect(() => {
    if (!clientRef.current || pendingChanges.length === 0) return;

    clientRef.current.sendMessage({
      type: 'SHOW_PENDING_CHANGES',
      changes: pendingChanges
    });
  }, [pendingChanges]);

  return (
    <div style={{ width: '100%', height: '600px', position: 'relative' }}>
      <div style={{
        position: 'absolute',
        top: '10px',
        right: '10px',
        padding: '8px 16px',
        backgroundColor: status === 'Connected' ? '#4CAF50' : '#FF9800',
        color: '#fff',
        borderRadius: '4px',
        fontSize: '12px',
        fontWeight: 'bold',
        zIndex: 10
      }}>
        {status}
      </div>
      <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#000' }} />
    </div>
  );
}

export default NvidiaCloudXRViewer;
```

### Option 3: IFrame Embedding

Best for: Existing Omniverse web application, simple integration

#### Component Template

```javascript
// frontend/src/components/NvidiaOmniverseIframe.js
import React, { useEffect, useRef } from 'react';

function NvidiaOmniverseIframe({ displayData, highlightItems, pendingChanges }) {
  const iframeRef = useRef(null);

  // Set up message listener for responses from iframe
  useEffect(() => {
    const handleMessage = (event) => {
      // Verify origin for security
      if (event.origin !== process.env.REACT_APP_OMNIVERSE_IFRAME_ORIGIN) {
        return;
      }

      console.log('Received from Omniverse iframe:', event.data);

      if (event.data.type === 'SCENE_LOADED') {
        console.log('Omniverse scene loaded successfully');
      } else if (event.data.type === 'ITEM_CLICKED') {
        console.log('User clicked item:', event.data.sku_id);
        // Handle item clicks in your React app
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Send displayData to iframe
  useEffect(() => {
    if (!iframeRef.current || !displayData) return;

    iframeRef.current.contentWindow?.postMessage({
      type: 'UPDATE_STORE_LAYOUT',
      data: displayData
    }, process.env.REACT_APP_OMNIVERSE_IFRAME_ORIGIN);
  }, [displayData]);

  // Send highlight commands
  useEffect(() => {
    if (!iframeRef.current || highlightItems.length === 0) return;

    iframeRef.current.contentWindow?.postMessage({
      type: 'HIGHLIGHT_ITEMS',
      items: highlightItems
    }, process.env.REACT_APP_OMNIVERSE_IFRAME_ORIGIN);
  }, [highlightItems]);

  // Send pending changes
  useEffect(() => {
    if (!iframeRef.current || pendingChanges.length === 0) return;

    iframeRef.current.contentWindow?.postMessage({
      type: 'SHOW_PENDING_CHANGES',
      changes: pendingChanges
    }, process.env.REACT_APP_OMNIVERSE_IFRAME_ORIGIN);
  }, [pendingChanges]);

  return (
    <iframe
      ref={iframeRef}
      src={process.env.REACT_APP_OMNIVERSE_VIEWER_URL}
      style={{
        width: '100%',
        height: '600px',
        border: 'none',
        borderRadius: '8px'
      }}
      title="NVIDIA Omniverse Store Viewer"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    />
  );
}

export default NvidiaOmniverseIframe;
```

---

## 🔧 Replacing the Placeholder

### Step 1: Backup Original (Optional)

```bash
cp frontend/src/components/ThreeDViewer.js frontend/src/components/ThreeDViewer.backup.js
```

### Step 2: Choose Your Approach

**Approach A: Direct Replacement**

Replace the entire content of `ThreeDViewer.js` with your Omniverse component code, keeping the same filename.

**Approach B: New File (Recommended)**

Create your new component file, then update `DailyPlan.js`:

```javascript
// frontend/src/components/DailyPlan.js

// OLD:
import ThreeDViewer from './ThreeDViewer';

// NEW:
import NvidiaOmniverseViewer from './NvidiaOmniverseViewer';
// or NvidiaCloudXRViewer or NvidiaOmniverseIframe

// Update the JSX:
<NvidiaOmniverseViewer 
  displayData={plan}
  highlightItems={highlightItems}
  pendingChanges={pendingChanges}
/>
```

---

## 🌐 Environment Configuration

Create or update `frontend/.env`:

```env
# Omniverse Kit
REACT_APP_OMNIVERSE_SERVER_URL=omniverse://your-nucleus-server/projects/retail

# CloudXR
REACT_APP_CLOUDXR_SERVER=your-cloudxr-server.com
REACT_APP_CLOUDXR_PORT=48010

# IFrame
REACT_APP_OMNIVERSE_VIEWER_URL=https://your-omniverse-viewer.com/store
REACT_APP_OMNIVERSE_IFRAME_ORIGIN=https://your-omniverse-viewer.com

# API Keys (if required)
REACT_APP_NVIDIA_API_KEY=your-nvidia-api-key
```

---

## 🔗 Connecting "See in Store" Feature

### Current State

In `Analytics.js`, the "See in Store" buttons currently show an alert:

```javascript
const handleSeeInStore = async (action) => {
  alert(`Action: ${action}\n\nThis will update the 3D store view.`);
};
```

### What You Need To Implement

Update `Analytics.js` to navigate to the 3D viewer with data:

```javascript
const handleSeeInStore = async (action) => {
  // Option 1: Using React Router (if you add it)
  navigate('/3d-viewer', {
    state: {
      highlightItems: [action.sku_id],
      pendingChanges: [{
        type: action.action,
        sku_id: action.sku_id,
        reason: action.description
      }]
    }
  });

  // Option 2: Using App-level state (simpler)
  // Pass these as props from App.js:
  set3DViewerData({
    highlightItems: [action.sku_id],
    pendingChanges: [{
      type: action.action,
      sku_id: action.sku_id,
      from: getCurrentItemPosition(action.sku_id),
      to: getRecommendedPosition(action.action),
      reason: action.description
    }]
  });
  
  setActiveTab('3d-viewer'); // Switch to 3D viewer tab
};
```

### Modify App.js for State Management

```javascript
// frontend/src/App.js
import React, { useState } from 'react';

function App() {
  const [activeTab, setActiveTab] = useState('analytics');
  const [viewer3DData, setViewer3DData] = useState({
    highlightItems: [],
    pendingChanges: []
  });

  return (
    <div>
      {/* Navigation */}
      {activeTab === 'analytics' && (
        <Analytics 
          setActiveTab={setActiveTab}
          setViewer3DData={setViewer3DData}
        />
      )}
      {activeTab === '3d-viewer' && (
        <DailyPlan 
          highlightItems={viewer3DData.highlightItems}
          pendingChanges={viewer3DData.pendingChanges}
        />
      )}
    </div>
  );
}
```

### Modify DailyPlan.js to Accept Props

```javascript
// frontend/src/components/DailyPlan.js
function DailyPlan({ highlightItems = [], pendingChanges = [] }) {
  const [plan, setPlan] = useState(null);

  return (
    <div>
      <h2>3D Store Viewer</h2>
      
      {/* Show pending changes banner if any */}
      {pendingChanges.length > 0 && (
        <div style={styles.changesBanner}>
          <h3>📦 Recommended Changes ({pendingChanges.length})</h3>
          <ul>
            {pendingChanges.map((change, idx) => (
              <li key={idx}>
                <strong>{change.type}:</strong> {change.reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      <NvidiaOmniverseViewer 
        displayData={plan}
        highlightItems={highlightItems}
        pendingChanges={pendingChanges}
      />
    </div>
  );
}
```

---

## 🧪 Testing Your Integration

### 1. Basic Rendering Test

```bash
# Start the app
cd frontend && npm start

# Navigate to 3D Store Viewer tab
# Verify:
- [ ] Omniverse scene loads without errors
- [ ] Store layout is visible
- [ ] Camera controls work (rotate, zoom, pan)
```

### 2. Data Flow Test

```bash
# In 3D Store Viewer:
# Click "Generate Today's Update Plan"
# Verify:
- [ ] displayData is received (check React DevTools)
- [ ] Items update in the scene
- [ ] No console errors
```

### 3. Highlighting Test

```bash
# From Analytics tab:
# Click any "See in Store" button
# Verify:
- [ ] Navigates to 3D Store Viewer
- [ ] Item is highlighted in gold/yellow
- [ ] Camera focuses on the item
- [ ] Highlight pulses or stands out
```

### 4. Pending Changes Test

```bash
# When "See in Store" with a "move" action:
# Verify:
- [ ] Arrow shows from → to positions
- [ ] Label explains the reason
- [ ] Colors are appropriate (green for move, etc.)
```

---

## 📊 Common Omniverse Operations

### Loading Scenes

```javascript
// Load base store USD
await omniverseClient.loadUSD('omniverse://localhost/retail/store_v1.usd');

// Load with specific camera
await omniverseClient.loadUSD('omniverse://localhost/retail/store_v1.usd', {
  cameraPath: '/World/Camera_Front'
});
```

### Updating Objects

```javascript
// Move an item
await omniverseClient.updatePrim('/World/Store/Items/SKU001', {
  position: [x, y, z],
  rotation: [rx, ry, rz]
});

// Change material
await omniverseClient.applyMaterial('/World/Store/Items/SKU001', {
  material: '/World/Materials/GoldHighlight',
  emissive_color: [1.0, 0.84, 0.0],
  emissive_intensity: 2.0
});
```

### Camera Control

```javascript
// Focus on object
await omniverseClient.focusCamera('/World/Store/Items/SKU001');

// Set camera position
await omniverseClient.setCamera({
  position: [10, 5, 10],
  target: [0, 0, 0],
  fov: 60
});

// Animate camera
await omniverseClient.animateCamera({
  from: currentPosition,
  to: targetPosition,
  duration: 2.0,
  easing: 'ease-in-out'
});
```

### Creating Visual Indicators

```javascript
// Create arrow for movement
await omniverseClient.createPrim('/World/Indicators/MoveArrow', {
  type: 'Arrow',
  from: [x1, y1, z1],
  to: [x2, y2, z2],
  color: [0, 1, 0],
  thickness: 0.1
});

// Create floating label
await omniverseClient.createPrim('/World/Labels/Action1', {
  type: 'Text',
  text: 'Move to front',
  position: [x, y + 2, z],
  billboard: true,
  color: [1, 1, 1]
});
```

---

## 🐛 Troubleshooting

### Omniverse Scene Not Loading

**Problem:** Black screen or loading forever

**Solutions:**
- Check Nucleus server is running and accessible
- Verify USD file path is correct
- Check browser console for WebGL errors
- Ensure WebRTC is enabled in browser
- Test connection with `omniverseClient.testConnection()`

### High Latency / Poor Performance

**Problem:** Laggy interaction, low FPS

**Solutions:**
- Use CloudXR for better streaming
- Reduce polygon count in USD scene
- Enable LOD (Level of Detail)
- Check network bandwidth
- Use progressive loading for large scenes

### Items Not Highlighting

**Problem:** Highlight effect not visible

**Solutions:**
- Verify SKU IDs match exactly (case-sensitive)
- Check prim paths are correct: `/World/Store/Items/{sku_id}`
- Ensure materials support emissive properties
- Debug with console.log in useEffect
- Try applying material override instead

### CORS Errors

**Problem:** Cannot connect to Omniverse server

**Solutions:**
- Add CORS headers to Omniverse server
- Use proxy if necessary
- Check `Access-Control-Allow-Origin` settings
- For IFrame: verify origin in postMessage

---

## 📚 Resources

### NVIDIA Documentation
- [Omniverse Platform](https://docs.omniverse.nvidia.com/)
- [CloudXR SDK](https://developer.nvidia.com/cloudxr-sdk)
- [Omniverse Kit SDK](https://docs.omniverse.nvidia.com/kit/docs/kit-sdk)
- [USD Documentation](https://graphics.pixar.com/usd/docs/)

### Examples & Tutorials
- [Omniverse Web Viewer Examples](https://docs.omniverse.nvidia.com/extensions/latest/ext_web-viewer.html)
- [CloudXR Samples](https://developer.nvidia.com/cloudxr-sdk#samples)
- [USD Python API](https://graphics.pixar.com/usd/docs/api/index.html)

### Community
- [NVIDIA Developer Forums](https://forums.developer.nvidia.com/)
- [Omniverse Discord](https://discord.gg/nvidia)

---

## ✅ Checklist

Before marking integration complete:

- [ ] Omniverse component created
- [ ] Props properly received and used
- [ ] Scene loads without errors
- [ ] Items display correctly
- [ ] Highlighting works
- [ ] Pending changes visualized
- [ ] "See in Store" navigation works
- [ ] Tested on multiple browsers
- [ ] Documentation updated
- [ ] Code reviewed by team

---

## 🎉 Next Steps

Once your Omniverse integration is complete:

1. **Test with real store data** - Use actual SKU positions
2. **Add user interactions** - Click items, drag to rearrange
3. **Implement "Apply Changes"** - Save new layouts to database
4. **Add before/after comparison** - Show current vs. recommended
5. **Create guided tours** - Highlight all changes in sequence
6. **Add analytics tracking** - Monitor which recommendations are applied
7. **Optimize performance** - Profile and improve render times
8. **Deploy to staging** - Test with full team


