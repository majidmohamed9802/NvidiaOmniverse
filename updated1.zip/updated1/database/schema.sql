-- AI Visual Merchandiser Database Schema
-- For PostgreSQL on Cloud SQL

-- SKU Master Table
CREATE TABLE skus (
    sku_id VARCHAR(50) PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    sub_category VARCHAR(100),
    brand VARCHAR(100),
    color VARCHAR(50),
    size VARCHAR(20),
    cost_price DECIMAL(10, 2),
    selling_price DECIMAL(10, 2),
    margin_percentage DECIMAL(5, 2),
    stock_quantity INTEGER,
    season VARCHAR(50),
    arrival_date DATE,
    is_new_arrival BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sales Data Table
CREATE TABLE sales_data (
    sale_id SERIAL PRIMARY KEY,
    sku_id VARCHAR(50) REFERENCES skus(sku_id),
    store_zone VARCHAR(50),
    quantity_sold INTEGER,
    sale_amount DECIMAL(10, 2),
    sale_date DATE,
    week_number INTEGER,
    month_number INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Display History Table
CREATE TABLE display_history (
    display_id SERIAL PRIMARY KEY,
    display_name VARCHAR(255),
    focus_area VARCHAR(100),
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'draft',
    execution_date DATE,
    notes TEXT
);

-- Display SKU Mapping
CREATE TABLE display_skus (
    id SERIAL PRIMARY KEY,
    display_id INTEGER REFERENCES display_history(display_id),
    sku_id VARCHAR(50) REFERENCES skus(sku_id),
    placement_location VARCHAR(100),
    quantity INTEGER,
    priority INTEGER
);

-- Performance Metrics Table
CREATE TABLE display_performance (
    metric_id SERIAL PRIMARY KEY,
    display_id INTEGER REFERENCES display_history(display_id),
    zone VARCHAR(50),
    sales_lift_percentage DECIMAL(5, 2),
    units_sold INTEGER,
    measurement_start_date DATE,
    measurement_end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Slow Movers Tracking
CREATE TABLE slow_movers (
    id SERIAL PRIMARY KEY,
    sku_id VARCHAR(50) REFERENCES skus(sku_id),
    days_without_sale INTEGER,
    stock_quantity INTEGER,
    flagged_date DATE,
    action_taken VARCHAR(255),
    resolved BOOLEAN DEFAULT FALSE
);

-- Create indexes for performance
CREATE INDEX idx_skus_category ON skus(category);
CREATE INDEX idx_skus_season ON skus(season);
CREATE INDEX idx_sales_sku ON sales_data(sku_id);
CREATE INDEX idx_sales_date ON sales_data(sale_date);
CREATE INDEX idx_sales_zone ON sales_data(store_zone);
CREATE INDEX idx_display_status ON display_history(status);
