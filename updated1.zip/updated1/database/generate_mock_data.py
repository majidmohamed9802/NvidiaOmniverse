"""
Mock Data Generator for AI Visual Merchandiser
Generates realistic SKU and sales data for testing
"""

import random
import json
from datetime import datetime, timedelta

# Product categories and attributes
CATEGORIES = {
    "Apparel": {
        "sub_categories": ["Sweaters", "Shirts", "Pants", "Jackets", "Dresses"],
        "brands": ["Cashmere Collection", "Wool Treasures", "Cotton Comfort", "Leather Luxe"]
    },
    "Accessories": {
        "sub_categories": ["Bags", "Belts", "Scarves", "Hats", "Gloves"],
        "brands": ["Premium Leather", "Silk Stories", "Textile Tales"]
    },
    "Footwear": {
        "sub_categories": ["Boots", "Sneakers", "Loafers", "Sandals"],
        "brands": ["Comfort Steps", "Luxury Walk", "Sport Elite"]
    }
}

COLORS = ["Black", "Navy", "Gray", "Brown", "White", "Cream", "Burgundy", "Olive", "Camel"]
SIZES = ["XS", "S", "M", "L", "XL", "XXL"]
SEASONS = ["Fall/Winter", "Spring/Summer", "All Season"]
STORE_ZONES = ["Front Window", "Central Mannequin", "Focus Table", "Perimeter Wall", "Accessories Corner", "Clearance"]

def generate_sku_id(category, index):
    """Generate SKU ID"""
    prefix = category[:3].upper()
    return f"{prefix}{str(index).zfill(5)}"

def generate_skus(num_skus=100):
    """Generate mock SKU data"""
    skus = []
    sku_index = 1
    
    for category, details in CATEGORIES.items():
        num_category_skus = num_skus // len(CATEGORIES)
        
        for i in range(num_category_skus):
            sub_cat = random.choice(details["sub_categories"])
            brand = random.choice(details["brands"])
            color = random.choice(COLORS)
            size = random.choice(SIZES) if category == "Apparel" else "ONE SIZE"
            
            cost_price = round(random.uniform(20, 150), 2)
            markup = random.uniform(2.0, 3.5)
            selling_price = round(cost_price * markup, 2)
            margin = round(((selling_price - cost_price) / selling_price) * 100, 2)
            
            arrival_date = datetime.now() - timedelta(days=random.randint(1, 180))
            is_new = (datetime.now() - arrival_date).days < 30
            
            sku = {
                "sku_id": generate_sku_id(category, sku_index),
                "product_name": f"{brand} {sub_cat}",
                "category": category,
                "sub_category": sub_cat,
                "brand": brand,
                "color": color,
                "size": size,
                "cost_price": cost_price,
                "selling_price": selling_price,
                "margin_percentage": margin,
                "stock_quantity": random.randint(5, 100),
                "season": random.choice(SEASONS),
                "arrival_date": arrival_date.strftime("%Y-%m-%d"),
                "is_new_arrival": is_new
            }
            
            skus.append(sku)
            sku_index += 1
    
    return skus

def generate_sales_data(skus, num_weeks=12):
    """Generate mock sales data"""
    sales = []
    sale_id = 1
    
    start_date = datetime.now() - timedelta(weeks=num_weeks)
    
    for sku in skus:
        # Some SKUs sell better than others
        velocity = random.choice(["fast", "medium", "slow", "very_slow"])
        
        if velocity == "fast":
            sales_frequency = 0.8  # 80% chance of sale per week
            avg_units = random.randint(5, 15)
        elif velocity == "medium":
            sales_frequency = 0.5
            avg_units = random.randint(2, 7)
        elif velocity == "slow":
            sales_frequency = 0.3
            avg_units = random.randint(1, 3)
        else:  # very_slow
            sales_frequency = 0.1
            avg_units = 1
        
        for week in range(num_weeks):
            if random.random() < sales_frequency:
                sale_date = start_date + timedelta(weeks=week, days=random.randint(0, 6))
                zone = random.choice(STORE_ZONES)
                quantity = random.randint(1, avg_units)
                
                sale = {
                    "sale_id": sale_id,
                    "sku_id": sku["sku_id"],
                    "store_zone": zone,
                    "quantity_sold": quantity,
                    "sale_amount": round(quantity * sku["selling_price"], 2),
                    "sale_date": sale_date.strftime("%Y-%m-%d"),
                    "week_number": week + 1,
                    "month_number": sale_date.month
                }
                
                sales.append(sale)
                sale_id += 1
    
    return sales

def generate_display_history():
    """Generate some historical display data"""
    displays = [
        {
            "display_id": 1,
            "display_name": "Holiday Window Display",
            "focus_area": "Front Window",
            "created_by": "Sarah Chen",
            "status": "completed",
            "execution_date": (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"),
            "notes": "Featured winter collection with premium cashmere pieces"
        },
        {
            "display_id": 2,
            "display_name": "New Arrivals Focus Table",
            "focus_area": "Central Mannequin",
            "created_by": "Sarah Chen",
            "status": "active",
            "execution_date": (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
            "notes": "Showcasing spring preview collection"
        }
    ]
    
    return displays

def identify_slow_movers(skus, sales):
    """Identify slow-moving SKUs"""
    # Calculate days since last sale for each SKU
    sku_last_sale = {}
    
    for sale in sales:
        sale_date = datetime.strptime(sale["sale_date"], "%Y-%m-%d")
        sku_id = sale["sku_id"]
        
        if sku_id not in sku_last_sale or sale_date > sku_last_sale[sku_id]:
            sku_last_sale[sku_id] = sale_date
    
    slow_movers = []
    slow_mover_id = 1
    
    for sku in skus:
        sku_id = sku["sku_id"]
        
        if sku_id in sku_last_sale:
            days_since_sale = (datetime.now() - sku_last_sale[sku_id]).days
        else:
            # Never sold
            arrival = datetime.strptime(sku["arrival_date"], "%Y-%m-%d")
            days_since_sale = (datetime.now() - arrival).days
        
        # Flag if no sale in 30+ days and has stock
        if days_since_sale >= 30 and sku["stock_quantity"] > 0:
            slow_movers.append({
                "id": slow_mover_id,
                "sku_id": sku_id,
                "days_without_sale": days_since_sale,
                "stock_quantity": sku["stock_quantity"],
                "flagged_date": datetime.now().strftime("%Y-%m-%d"),
                "action_taken": None,
                "resolved": False
            })
            slow_mover_id += 1
    
    return slow_movers

def main():
    """Generate all mock data"""
    print("Generating mock data...")
    
    # Generate data
    skus = generate_skus(100)
    sales = generate_sales_data(skus, 12)
    displays = generate_display_history()
    slow_movers = identify_slow_movers(skus, sales)
    
    # Save to JSON files
    data = {
        "skus": skus,
        "sales_data": sales,
        "display_history": displays,
        "slow_movers": slow_movers
    }
    
    with open("/home/claude/ai-visual-merchandiser/database/mock_data.json", "w") as f:
        json.dump(data, f, indent=2)
    
    print(f"\nGenerated:")
    print(f"  - {len(skus)} SKUs")
    print(f"  - {len(sales)} sales records")
    print(f"  - {len(displays)} display records")
    print(f"  - {len(slow_movers)} slow-moving SKUs")
    print(f"\nData saved to: /home/claude/ai-visual-merchandiser/database/mock_data.json")
    
    # Print summary statistics
    print("\n--- Summary Statistics ---")
    total_revenue = sum(sale["sale_amount"] for sale in sales)
    print(f"Total Revenue: ${total_revenue:,.2f}")
    
    zone_sales = {}
    for sale in sales:
        zone = sale["store_zone"]
        zone_sales[zone] = zone_sales.get(zone, 0) + sale["sale_amount"]
    
    print("\nRevenue by Zone:")
    for zone, revenue in sorted(zone_sales.items(), key=lambda x: x[1], reverse=True):
        print(f"  {zone}: ${revenue:,.2f}")

if __name__ == "__main__":
    main()
